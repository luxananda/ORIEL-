# EQL · ORIEL — VS Code / Cursor extension

Reads the code in your editor → plain English, schema & rules, or an Oracle migration —
powered by Claude, with the API key on a backend (never on your machine). Right-click a
selection or use the Command Palette:

- **EQL: Translate selection to plain English** — every statement, tagged DEF / READ / WRITE.
- **EQL: Extract schema & rules** — tables, columns, keys, rules, each tagged EXTRACTED / INFERRED.
- **EQL: Migrate to Oracle** — dialect mappings + generated Oracle PL/SQL, opened in a new editor.

Results render in a side panel styled in the EQL editorial language.

```
package.json        the extension manifest (commands, menus, settings)
extension.js        reads the selection, calls the backend, renders the panel
backend/            the shared Claude backend (run separately; key lives here)
```

## 1) Run the backend (holds the key)

```bash
cd backend
npm install
cp .env.example .env        # paste your ANTHROPIC_API_KEY
npm run serve               # http://localhost:3000
```

This is the **same backend** the Excel add-in uses — one service, two front-ends. In
production, don't run it locally: point the extension setting `eql.backendUrl` at your
approved enterprise-AI gateway.

## 2) Run the extension (dev)

Open this folder in VS Code → press **F5**. A second window (Extension Development Host)
opens with EQL active. Open a `.sql`/`.pls` file, select some code, right-click → **EQL: …**.

## 3) Package it

```bash
npm install -g @vscode/vsce
vsce package                # produces eql-1.0.0.vsix
```
(Set a real `publisher` in package.json first if you'll publish.)

## 4) Install in VS Code

```bash
code --install-extension eql-1.0.0.vsix
```
…or in VS Code: **Extensions: Install from VSIX…** and pick the file.

## 5) Install in Cursor (same VSIX — no separate build)

Cursor is VS Code-based and uses the Open VSX registry, and installs VSIX directly:
- Drag `eql-1.0.0.vsix` into Cursor's Extensions pane, **or**
- Command Palette → **Extensions: Install from VSIX…**, **or**
- `cursor --install-extension eql-1.0.0.vsix`

To make it appear in Cursor's marketplace for others, publish once to **Open VSX**
(https://open-vsx.org) with `npx ovsx publish eql-1.0.0.vsix -p <token>`.

## Security

- The API key lives only on the backend; the extension calls it over HTTP(S) and never
  sees the key. Set `eql.backendUrl` to your enterprise-AI gateway in production.
- Generated SQL is shown/opened, **never executed**.
- `extract` tags every fact EXTRACTED vs INFERRED — provenance travels with the output.

## Upgrade to your real EQL skills

`backend/server.js` inlines the method so it runs immediately. To use your uploaded skills,
uncomment the `betas` / `container.skills` / `tools` block (load `eql-orchestrator` + the
few relevant skills; max 8 per request) and add the `anthropic-beta` header.
