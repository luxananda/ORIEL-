/* EQL backend (shared by the Excel add-in and the VS Code/Cursor extension).
   The Anthropic API key lives ONLY here. POST /api/eql {mode, code}. */
require("dotenv").config({ path: require("path").join(__dirname, ".env") });
const express = require("express");
const cors = require("cors");

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.EQL_MODEL || "claude-sonnet-4-6";

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const SYS = {
  translate: `You are the EQL engine. Translate the given SQL / PL code into plain English,
one meaningful statement at a time. Classify each: DEF (declaration/definition),
READ (query), or WRITE (insert/update/delete/merge). Be precise and brief.
Return STRICT JSON only, no prose, no code fences:
{"title":"Plain English","items":[{"tag":"DEF|READ|WRITE","text":"..."}]}`,

  extract: `You are the EQL engine. From the code \u2014 especially its writes \u2014 extract the schema and logic:
entities/tables, columns with detail, relationships (foreign keys), and business rules.
Tag every fact EXTRACTED (read directly from the code) or INFERRED (derived from context).
Return STRICT JSON only:
{"title":"Schema & Logic","table":{"cols":["Entity","Attribute / Detail","Provenance"],
"rows":[["ACCOUNTS","account_id (primary key)","INFERRED"],["ACCOUNTS","balance (NUMERIC)","EXTRACTED"]]}}`,

  migrate: `You are the EQL engine. Re-express the given code in Oracle PL/SQL, preserving meaning.
List the dialect mappings you applied, then output the generated Oracle code. Do NOT execute anything.
Return STRICT JSON only:
{"title":"Migrate to Oracle","mappings":[["now()","SYSTIMESTAMP"],["INT","NUMBER"]],"code":"<oracle plsql>"}`,

  glossary: `You are the EQL glossary engine for a tier-1 bank. For each distinct business concept in the
input, produce one governed glossary row. Never invent an owner; status is always "proposed";
add a FIBO/ISO 20022 reference where it clearly applies.
Return STRICT JSON only:
{"title":"Glossary","table":{"cols":["Term","Definition","Domain","Owner","Status","Reference"],
"rows":[["...","...","...","","proposed","..."]]}}`
};

app.post("/api/eql", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).send("ANTHROPIC_API_KEY not set on the server.");
    const mode = req.body.mode;
    const code = (req.body.code || "").slice(0, 24000);
    if (!SYS[mode]) return res.status(400).send("Unknown mode: " + mode);
    if (!code.trim()) return res.status(400).send("No code provided.");

    const body = {
      model: MODEL, max_tokens: 4000, system: SYS[mode],
      messages: [{ role: "user", content: code }]
      // UPGRADE: swap SYS[mode] for your uploaded EQL skills via
      // betas:["code-execution-2025-08-25","skills-2025-10-02"],
      // container:{skills:[{type:"custom",skill_id:process.env.SKILL_ORCHESTRATOR,version:"latest"}]},
      // tools:[{type:"code_execution_20250825",name:"code_execution"}]
    };
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify(body)
    });
    if (!r.ok) return res.status(502).send("Claude API " + r.status + ": " + (await r.text()));
    const data = await r.json();
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    res.json(parse(text));
  } catch (e) {
    console.error(e); res.status(500).send(String(e.message || e));
  }
});

function parse(text) {
  let s = (text || "").trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  try { return JSON.parse(s); } catch { return { title: "EQL", items: [{ tag: "DEF", text: text.slice(0, 1200) }] }; }
}

app.listen(PORT, () => console.log(`EQL backend on http://localhost:${PORT}  (modes: translate, extract, migrate, glossary)`));
