const vscode = require("vscode");

function activate(context) {
  const run = (mode) => async () => {
    const ed = vscode.window.activeTextEditor;
    if (!ed) { vscode.window.showWarningMessage("EQL: open a file first."); return; }
    const sel = ed.selection;
    const code = sel && !sel.isEmpty ? ed.document.getText(sel) : ed.document.getText();
    if (!code.trim()) { vscode.window.showWarningMessage("EQL: nothing to read \u2014 select some code."); return; }

    const base = vscode.workspace.getConfiguration("eql").get("backendUrl");
    try {
      const env = await vscode.window.withProgress(
        { location: vscode.ProgressLocation.Notification, title: `EQL: ${mode}\u2026` },
        async () => {
          const r = await fetch(`${base}/api/eql`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mode, code })
          });
          if (!r.ok) throw new Error(`Backend ${r.status}: ${await r.text()}`);
          return r.json();
        }
      );

      // migrate: open the generated SQL in a new editor, beside
      if (mode === "migrate" && env.code) {
        const doc = await vscode.workspace.openTextDocument({ language: "sql", content: env.code });
        await vscode.window.showTextDocument(doc, vscode.ViewColumn.Beside);
      }
      showPanel(context, env);
    } catch (err) {
      vscode.window.showErrorMessage("EQL error: " + (err.message || err));
    }
  };

  context.subscriptions.push(
    vscode.commands.registerCommand("eql.translate", run("translate")),
    vscode.commands.registerCommand("eql.extract", run("extract")),
    vscode.commands.registerCommand("eql.migrate", run("migrate"))
  );
}

let panel;
function showPanel(context, env) {
  if (!panel) {
    panel = vscode.window.createWebviewPanel("eql", "EQL \u00b7 ORIEL", vscode.ViewColumn.Beside, { enableScripts: false });
    panel.onDidDispose(() => (panel = undefined));
  }
  panel.webview.html = render(env);
  panel.reveal(vscode.ViewColumn.Beside, true);
}

const esc = (s) => String(s == null ? "" : s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
const TAGC = { EXTRACTED: "#73806B", INFERRED: "#3C4752", MIXED: "#BE9C57", WRITE: "#B0664B", READ: "#6E675C", DEF: "#6E675C" };

function render(env) {
  const tag = (t) => `<span class="tag" style="--c:${TAGC[t] || "#6E675C"}">${esc(t)}</span>`;
  let body = "";
  if (env.items) {
    body += env.items.map((it) => `<div class="card">${tag(it.tag)}<p>${esc(it.text)}</p></div>`).join("");
  }
  if (env.table) {
    const { cols, rows } = env.table;
    body += `<table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>` +
      rows.map((r) => `<tr>` + r.map((cell, i) =>
        i === r.length - 1 && TAGC[cell] ? `<td>${tag(cell)}</td>` : `<td>${esc(cell)}</td>`
      ).join("") + `</tr>`).join("") + `</tbody></table>`;
  }
  if (env.mappings) {
    body += `<div class="chips">` + env.mappings.map((m) =>
      `<span class="chip">${esc(m[0])} <b>\u2192</b> ${esc(m[1])}</span>`).join("") + `</div>`;
  }
  if (env.code) {
    body += `<div class="codehd">Generated \u2014 never executed</div><pre class="code">${esc(env.code)}</pre>`;
  }
  return `<!DOCTYPE html><html><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com;">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400..600&family=Inter+Tight:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
 :root{--paper:#F6F1E7;--ink:#2B2722;--soft:#6E675C;--faint:#9A9386;--clay:#B0664B;--line:#E3DBCB;--card:#FBF8F1;--code:#26221D}
 body{background:var(--paper);color:var(--ink);font-family:"Inter Tight",sans-serif;padding:22px 24px;margin:0}
 .mark{font-family:"JetBrains Mono",monospace;font-size:11px;letter-spacing:.14em;color:var(--clay);text-transform:uppercase}
 h1{font-family:"Fraunces",serif;font-weight:500;font-size:24px;margin:6px 0 18px}
 .tag{font-family:"JetBrains Mono",monospace;font-size:10px;font-weight:700;letter-spacing:.04em;color:var(--c);border:1px solid var(--c);border-radius:999px;padding:2px 9px;background:color-mix(in srgb,var(--c) 14%,transparent)}
 .card{background:var(--card);border:1px solid var(--line);border-radius:11px;padding:12px 16px;margin:10px 0;box-shadow:0 4px 14px rgba(43,39,34,.05)}
 .card p{margin:8px 0 0;font-size:14px}
 table{border-collapse:collapse;width:100%;margin:6px 0 16px}
 th{font-family:"JetBrains Mono",monospace;font-size:10px;letter-spacing:.06em;color:var(--faint);text-align:left;padding:8px 10px;border-bottom:1px solid var(--line)}
 td{font-size:13px;padding:9px 10px;border-bottom:1px solid var(--line)}
 td:first-child{font-family:"JetBrains Mono",monospace;font-weight:600;color:var(--clay);font-size:12px}
 .chips{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 16px}
 .chip{font-family:"JetBrains Mono",monospace;font-size:12px;background:var(--card);border:1px solid var(--line);border-radius:8px;padding:6px 10px;color:var(--soft)}
 .chip b{color:var(--faint)}
 .codehd{font-family:"JetBrains Mono",monospace;font-size:10px;color:var(--faint);letter-spacing:.05em;margin-bottom:6px}
 pre.code{background:var(--code);color:#E9E5DB;font-family:"JetBrains Mono",monospace;font-size:13px;line-height:1.55;padding:16px;border-radius:12px;overflow:auto;white-space:pre-wrap}
</style></head><body>
 <div class="mark">EQL \u00b7 ORIEL</div>
 <h1>${esc(env.title || "EQL")}</h1>
 ${body || "<p class='card'>No structured result returned.</p>"}
</body></html>`;
}

function deactivate() {}
module.exports = { activate, deactivate };
