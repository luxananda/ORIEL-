---
name: extract-domain-rules
description: Extract domain/business rules from code and docs: scan conditionals, normalize to IF-THEN, separate technical from business intent, detect implicit rules, tag by domain, and output business-readable rules. Use when the user wants the business rules, policies, eligibility, thresholds, or constraints encoded in a source.
---

# Extract Domain Rules

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The reference extractor for the spine; composes the rule primitives into business-readable rules in ORIEL.

## When to use
`extract domain-rules <source>` or `run`.

## Inputs
Normalized code/doc blocks.

## Composes (does not re-implement)
`conditional-scanner`, `if-then-normalizer`, `technical-business-separator`, `implicit-rule-detector`, `domain-tagger`, `plain-english-translator`

## Method
1. Run conditional-scanner to find conditionals/validations, then if-then-normalizer to canonicalize them.
2. Run technical-business-separator to keep business intent primary; run implicit-rule-detector for defaults/fallbacks/assumptions.
3. Run domain-tagger to facet rules by domain; run plain-english-translator for a business-readable statement per rule.
4. Link rules to the entities/fields they constrain via CONSTRAINS.

## Output → ORIEL
`Rule` and `ImplicitRule` nodes, CONSTRAINS edges, domain tags, and plain-English descriptions.

## Quality bar
- Explicit and implicit rules both captured and distinguished.
- Each rule has domain tag, business statement, and constrained target.
- Default/else branches preserved as their own rules.

## Provenance & governance
All rules proposed; thresholds named; everything EVIDENCED_BY source.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

