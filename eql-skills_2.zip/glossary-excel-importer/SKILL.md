---
name: glossary-excel-importer
description: Import an existing business glossary from Excel or CSV into ORIEL — terms, definitions, owners, domains, statuses, synonyms — mapping spreadsheet columns to glossary fields and de-duplicating against existing terms. Use to bring a current or legacy glossary into the engine as current state, and as the inbound half of the Excel round-trip.
---

# Glossary Excel Importer

**Layer:** Reference · Current-State  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Turns the spreadsheet stewards already maintain into governed current-state glossary nodes.

## When to use
Current-state capture, or 'import our glossary from this spreadsheet'.

## Inputs
An .xlsx/.csv glossary and (optionally) a column mapping.

## Composes (does not re-implement)
`entity-term-identifier`, `synonym-structural-refiner`, `xlsx`

## Method
1. Read the workbook/sheet; detect or confirm the column mapping (term, definition, owner, domain, status, synonyms, source).
2. Normalize and de-duplicate against existing glossary terms; cluster synonyms as SAME_AS candidates.
3. Import as current-state terms (status preserved), retaining the source cell as the provenance locator.
4. Flag rows missing an owner or definition for steward attention.

## Output → ORIEL
Current-state glossary `Term` nodes (owner/domain/status) provenanced to their source cells.

## Quality bar
- Column mapping confirmed, not guessed.
- Duplicates clustered, not silently merged.
- Every term retains its source cell.

## Provenance & governance
Imported terms are current-state evidence; ownership/definition gaps flagged for stewards.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

