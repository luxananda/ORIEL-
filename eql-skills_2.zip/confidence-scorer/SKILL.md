---
name: confidence-scorer
description: Assign a calibrated confidence (0–1) to each extracted node/edge from parse certainty, detection confidence, and inference depth, and route low-confidence items to review. Use as a cross-cutting pass after extraction.
---

# Confidence Scorer

**Layer:** Controls (Layer I)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Turns 'how sure are we' into a number that drives the review queue.

## When to use
Cross-cutting after extraction, before serving.

## Inputs
Proposed nodes/edges with their evidence.

## Method
1. Score from declared-vs-inferred status, detector confidence, parse cleanliness, and number of inference hops.
2. Propagate caps: nothing exceeds the confidence of the artifact detection it rests on.
3. Flag items below threshold for human-confirm-gate; group by domain and impact.

## Output → ORIEL
A confidence value on every node/edge and a prioritized low-confidence queue.

## Quality bar
- Inferred items score below declared ones.
- Confidence never exceeds upstream detection confidence.
- Low-confidence queue is prioritized by impact.

## Provenance & governance
Feeds the review workflow; sensitive-field tags always reviewed regardless of score.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

