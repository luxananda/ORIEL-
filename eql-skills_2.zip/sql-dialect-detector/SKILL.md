---
name: sql-dialect-detector
description: Detect the SQL dialect and version of a source — PostgreSQL, Oracle, MySQL, SQL Server, BigQuery, Snowflake, and others — from DDL syntax, system-catalog references, type names, and feature usage. Use at the start of any migration or whenever the SQL/DDL dialect is unknown.
---

# SQL Dialect Detector

**Layer:** Migration · Harvest  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Pins the source dialect so harvesting parses correctly and mapping knows the source side. Also confirms the target dialect/version.

## When to use
First step of `migrate`; any time SQL dialect is ambiguous.

## Inputs
SQL/DDL text or a database connection's catalog.

## Method
1. Match dialect signatures: SERIAL/IDENTITY vs SEQUENCE syntax, VARCHAR2/NUMBER (Oracle) vs NUMERIC/TEXT (Postgres), backticks (MySQL) vs double-quotes, LIMIT vs ROWNUM/FETCH FIRST, project.dataset.table (BigQuery).
2. Check catalog references (pg_catalog, ALL_TABLES/USER_TABLES, INFORMATION_SCHEMA) and built-in function names.
3. Infer version from version-specific features; emit confidence and ranked alternatives.

## Output → ORIEL
A `Dialect` node (name, version, confidence) attached to the source's SourceArtifacts.

## Quality bar
- Version inferred where features allow; otherwise flagged unknown.
- Ambiguous sources return ranked candidates, not a forced single answer.

## Provenance & governance
Dialect confidence caps the confidence of everything harvested from the source.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

