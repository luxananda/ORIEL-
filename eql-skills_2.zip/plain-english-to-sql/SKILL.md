---
name: plain-english-to-sql
description: Generate SQL/DDL/DML in a chosen dialect from a plain-English specification or an ORIEL semantic node — the reverse of code-to-plain-english. Use when the user describes a table, view, query, or rule in words and wants the SQL, or to re-author harvested logic as fresh SQL in a target dialect.
---

# Plain-English → SQL

**Layer:** Migration · Generate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Closes the round trip — meaning → SQL — and powers spec-driven object creation during migration.

## When to use
On any 'write the SQL for …' request; or in `migrate` for spec-driven new objects.

## Inputs
A plain-English spec or an ORIEL node (Entity/Rule/Formula/Workflow) + a target dialect.

## Composes (does not re-implement)
`type-system-mapper`, `identifier-rules-mapper`, `target-ddl-generator`

## Method
1. Parse the spec/node into canonical intent: entities, columns, relationships, predicates, aggregations.
2. Resolve types and identifiers for the target dialect via the mappers.
3. Generate the SQL — DDL for structure, DML/SELECT for queries — and annotate every assumption explicitly.
4. Never invent columns, joins, or filters not implied by the spec; flag ambiguity instead.

## Output → ORIEL
`GeneratedArtifact` (SQL) that DESCRIBES the spec/node, with assumptions recorded.

## Quality bar
- SQL valid for the target dialect.
- Assumptions surfaced, not hidden.
- No fabricated columns or joins.

## Provenance & governance
Proposed; ambiguous specs routed to review rather than guessed.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

