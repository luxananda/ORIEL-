---
name: data-migration-planner
description: Produce the data-movement plan — FK-respecting load order, per-column cast/transform expressions, null/default handling, sequence reseeding, batching, and an export/import or CDC strategy — to move rows from source to target. Use after schema generation to plan (not execute) the actual data transfer.
---

# Data-Migration Planner

**Layer:** Migration · Generate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Schema is half a migration; this plans the data half.

## When to use
Generate phase of `migrate`, after the target schema is generated.

## Inputs
The schema graph + TypeMappings; volumes if available.

## Composes (does not re-implement)
`type-system-mapper`, `key-join-detector`

## Method
1. Derive load order from the FK graph so parents load before children.
2. For each column, produce the cast/transform expression from its TypeMapping, with guards for lossy casts (truncation, precision, null).
3. Handle defaults, identity/sequence reseeding, and null policy; pick bulk export-import vs CDC by volume.
4. Define batch sizes and per-table reconciliation checkpoints (rowcount + checksum/aggregate).

## Output → ORIEL
A `MigrationPlan` node (ordered steps, transform expressions, strategy) plus generated load scripts.

## Quality bar
- Load order satisfies all FK constraints.
- Every lossy cast has an explicit guard.
- Reconciliation checkpoints defined per table.

## Provenance & governance
Plan + scripts only; no data is moved without explicit approval.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

