---
name: type-system-mapper
description: Map column data types from the source dialect to the target through a dialect-neutral canonical type system, preserving precision/scale, handling overflow, and flagging lossy conversions. Use during any migration to translate column types safely.
---

# Type-System Mapper

**Layer:** Migration · Map  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
The type brain. Always source type → canonical type → target type — never source→target directly — so a new dialect adds one mapping table, not N.

## When to use
Map phase of `migrate`; any cross-dialect type conversion.

## Inputs
Harvested Field nodes (with original + canonical types).

## Method
1. Normalize each source type to a canonical type, carrying precision, scale, timezone, and array flags.
2. Lower the canonical type to the target's best-fit type; preserve precision/scale where supported, widening or narrowing with explicit notes.
3. Flag lossy or approximate conversions with the specific risk (truncation, precision loss, semantic shift).
4. Emit a per-column TypeMapping with rationale and the retained source type.

## Output → ORIEL
`TypeMapping` nodes (source_type, canonical_type, target_type, lossy?, note) — one per field, MAPS_TO the field.

## Reference mappings
PostgreSQL→Oracle: `SERIAL`→IDENTITY or SEQUENCE+trigger · `TEXT`→`CLOB` (or `VARCHAR2(4000)` with truncation risk) · `BOOLEAN`→`NUMBER(1)`/`CHAR(1)` · `JSONB`→`JSON`/`CLOB` (+IS JSON) · `TIMESTAMPTZ`→`TIMESTAMP WITH TIME ZONE` · `UUID`→`RAW(16)`/`VARCHAR2(36)` · arrays→nested table or flatten. Oracle→BigQuery: `NUMBER(p,s)`→`NUMERIC`/`BIGNUMERIC`/`FLOAT64` by scale · `VARCHAR2`/`CLOB`→`STRING` · `DATE`/`TIMESTAMP`→`DATE`/`DATETIME`/`TIMESTAMP` (UTC semantics differ) · `RAW`→`BYTES`.

## Quality bar
- Every column mapped or flagged unmappable.
- Lossy conversions explicit, with the concrete risk.
- Precision/scale preserved or the loss documented.

## Provenance & governance
Lossy mappings feed migration-risk-report and require acknowledgement before sign-off.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

