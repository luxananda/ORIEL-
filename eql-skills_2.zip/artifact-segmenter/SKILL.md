---
name: artifact-segmenter
description: Split each artifact into addressable blocks (functions, classes, validation/processing/output sections, doc sections, table regions) with precise locators for provenance. Use during `run`/`extract` after language detection, before any extraction.
---

# Artifact Segmenter

**Layer:** Normalization (Layer C)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Produces the line-accurate units everything downstream cites. Good locators are what make ORIEL auditable.

## When to use
After language-framework-detector, before extractors run.

## Inputs
Classified SourceArtifact nodes.

## Method
1. For code: segment by entry points, functions, classes, and the validation→processing→output bands within them.
2. For docs: segment by heading hierarchy and tables; for spreadsheets: by sheet and contiguous region; for API specs: by operation.
3. Emit a stable locator per block (file:line-range, doc§path, sheet!range, api#operation).

## Output → ORIEL
Block descriptors attached to each SourceArtifact; locators reused as `provenance.locator` by every downstream node.

## Quality bar
- Every block has a precise, re-derivable locator.
- Segmentation is deterministic for an unchanged version.

## Provenance & governance
Locators are the backbone of provenance; no block, no extraction from it.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

