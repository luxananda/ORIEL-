---
name: query-graph
description: Answer read-only EQL queries over ORIEL — rules, lineage, entities, pii, formulas, workflows, catalog — using the three indices. Use for any `query` verb or when the user asks to retrieve what was extracted, by domain, field, or type. Never writes.
---

# Query Graph (EQL Views)

**Layer:** Serving (Layer H)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The read engine. Every 'show me X from the graph' resolves here.

## When to use
`query <view> [args]`; any retrieval over extracted facts.

## Inputs
A view name and arguments; the indexed ORIEL graph.

## Method
1. Resolve the view to a traversal/lookup over the right index (e.g. lineage → structural; rules --domain → lexical+structural).
2. Apply filters (domain, qualifier, status); default to surfacing proposed-vs-confirmed status in results.
3. Return results with their provenance so every answer is traceable; never mutate the graph.

## Output → ORIEL
Read-only result sets (rules, lineage chains, entity lists, PII maps, formula/workflow catalogs) with provenance.

## Quality bar
- Zero writes.
- Every result carries provenance and status.
- Filters (domain/qualifier/status) honoured.

## Provenance & governance
Can restrict to confirmed-only for authoritative reporting.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

