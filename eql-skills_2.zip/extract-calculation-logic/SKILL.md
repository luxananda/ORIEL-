---
name: extract-calculation-logic
description: Extract calculation logic with operational detail: operation sequence, decision branches, constants/configurable parameters, calculation order and dependencies, readable math descriptions, rounding/precision/units, and edge-case handling (zero, null, overflow). Use when the user wants precise calculation behaviour, numeric edge cases, or rounding/precision rules of a source.
---

# Extract Calculation Logic

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The precision-focused sibling of extract-formulas; captures how a calculation actually behaves numerically.

## When to use
`extract calculation-logic <source>` or `run` for numeric-heavy sources.

## Inputs
Normalized code/spreadsheet blocks with arithmetic.

## Composes (does not re-implement)
`conditional-scanner`, `if-then-normalizer`, `lineage-tracer`, `plain-english-translator`

## Method
1. Identify the operation sequence and decision branches; separate constants from configurable parameters.
2. Resolve calculation order and dependencies; produce a readable math description per expression.
3. Capture rounding, precision, and unit handling; detect edge-case handling for zero, null, and overflow.
4. Emit each formula with explanation and a worked example.

## Output → ORIEL
`Formula` nodes annotated with precision/rounding/units, dependency order, edge-case rules, and examples.

## Quality bar
- Rounding/precision/units recorded explicitly.
- Zero/null/overflow handling captured or flagged absent.
- Each formula has a worked example.

## Provenance & governance
Edge-case gaps flagged as risks for review.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

