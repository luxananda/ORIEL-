---
name: gap-analyzer
description: Compute the gap between our current model and the industry reference — missing concepts, divergent definitions, extra/local concepts, and structural gaps (missing relationships/keys) — and score conformance/coverage by domain. Use to produce the gap analysis that drives a north-star and roadmap.
---

# Gap Analyzer

**Layer:** Reference · Gap  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Turns the crosswalk into an actionable gap register and the exec-facing conformance score.

## When to use
Gap step of `benchmark`/`northstar`.

## Inputs
The crosswalk plus our model and the ReferenceModel.

## Composes (does not re-implement)
`reference-crosswalk-mapper`

## Method
1. From the crosswalk, classify each reference concept as covered / partially covered (broader/narrower) / missing in our model.
2. Classify each of our concepts as aligned / divergent / local-only (no reference match — may be legitimate bank-specific or genuine cruft).
3. Detect structural gaps: relationships, keys, or attributes present in the reference but absent in ours.
4. Score coverage and definitional alignment per domain; attach a recommendation to every gap item.

## Output → ORIEL
`GapItem` nodes (kind, severity, recommendation) + a `ConformanceScore` by domain.

## Quality bar
- Every gap classified and carries a recommendation.
- Local-only concepts judged (keep vs retire), not blindly flagged.
- Score is per-domain, not a single vanity number.

## Provenance & governance
The gap register is proposed analysis; severity and recommendations reviewed before they drive the roadmap.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

