---
name: reference-northstar-orchestrator
description: Plan and run industry benchmarking and north-star definition via EQL — load an industry reference, capture current state, crosswalk to the reference, run gap analysis, build the north-star (ontology / data model / data architecture), sequence a roadmap, and deliver Excel workbooks. Use when the user wants to benchmark a glossary or data model against an industry standard (FIBO, ISO 20022, BIAN), run a gap analysis, or define a target/north-star model, ontology, or data architecture.
---

# Reference & North-Star Orchestrator

**Layer:** Reference · Orchestration  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Owns the `benchmark` and `northstar` verbs. Sequences Reference-intake → Current-state → Crosswalk → Gap → North-star → Roadmap → Excel over ORIEL, reusing the core engine for current-state extraction. The reference is the benchmark; our context, with recorded rationale, sets the target.

## When to use
`benchmark`/`northstar` verbs, or any 'compare us to <standard> / build a target model' request.

## Inputs
A current-state source (repo/DB/glossary), a chosen reference (+version), and the target layer.

## Composes (does not re-implement)
`industry-reference-loader`, `glossary-builder`, `glossary-excel-importer`, `reference-crosswalk-mapper`, `definition-harmonizer`, `gap-analyzer`, `northstar-ontology-modeler`, `northstar-data-model-builder`, `target-state-blueprint`, `roadmap-sequencer`, `excel-workbook-emitter`, `human-confirm-gate`

## Method
1. Load the chosen reference(s) via industry-reference-loader and confirm the version.
2. Capture current state: reuse the core engine (ddl-harvester / ontology-modeler / entity-term-identifier) and import any existing glossary via glossary-excel-importer; assemble with glossary-builder.
3. Align: run reference-crosswalk-mapper then definition-harmonizer (our terms → reference, aliases preserved, definitions reconciled).
4. Gap: run gap-analyzer for the gap register + conformance score by domain.
5. North-star: at the requested layer run northstar-ontology-modeler and/or northstar-data-model-builder; capture rationale via target-state-blueprint.
6. Roadmap + deliver: roadmap-sequencer, then excel-workbook-emitter for the glossary, gap-analysis and north-star workbooks. All proposed; steward confirms via human-confirm-gate.

## Output → ORIEL
A benchmark/north-star manifest linking reference → current → crosswalk → gaps → north-star → roadmap → workbooks.

## Quality bar
- North-star is bank-specific, not the reference copied.
- Every gap has a recommendation; every deviation from the reference carries a design decision.
- Nothing authoritative without steward confirm.

## Provenance & governance
The reference is a benchmark, not an authority; our context wins with a recorded rationale; all writes proposed and human-gated.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

