---
name: migration-orchestrator
description: Plan and run a database/data migration end to end via EQL — harvest the source into ORIEL, map types/features/identifiers to the target dialect, generate target DDL/DML and a data-movement plan, then validate equivalence. Use when migrating a database or its objects between dialects (PostgreSQL→Oracle, Oracle→BigQuery, etc.) or converting schema/SQL to another platform.
---

# Migration Orchestrator

**Layer:** Migration · Orchestration  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Owns the `migrate <source> --to <dialect>` verb. Sequences Harvest → Map → Generate → Validate over ORIEL, using the graph as a dialect-neutral interlingua: lift source SQL up, lower target SQL down. Adding a new target dialect is a new lowering, not a new pairwise translator.

## When to use
`migrate` verb, or any 'convert/migrate this schema/SQL to <platform>' request.

## Inputs
A source (DB / DDL files / repo / connector) and a target dialect (+version).

## Composes (does not re-implement)
`sql-dialect-detector`, `ddl-harvester`, `stored-logic-harvester`, `type-system-mapper`, `feature-equivalence-mapper`, `identifier-rules-mapper`, `target-ddl-generator`, `stored-logic-translator`, `data-migration-planner`, `migration-equivalence-checker`, `migration-risk-report`, `human-confirm-gate`

## Method
1. Resolve the source via its connector; run sql-dialect-detector on the source and confirm the target dialect + version.
2. HARVEST: run ddl-harvester and stored-logic-harvester to capture every object — tables, columns, constraints, indexes, sequences, partitioning, views, procedures, triggers, aliases — dialect-neutrally into ORIEL.
3. MAP: run type-system-mapper, feature-equivalence-mapper, identifier-rules-mapper to produce target mappings with lossy/unsupported flags.
4. GENERATE: run target-ddl-generator, stored-logic-translator, data-migration-planner (and plain-english-to-sql for any spec-driven new objects).
5. VALIDATE: run migration-equivalence-checker and migration-risk-report; route every generated artifact and all lossy/unsupported items through human-confirm-gate before anything is run.

## Output → ORIEL
A migration manifest linking harvested source objects → mappings → generated artifacts → validation report; everything proposed.

## Quality bar
- Every source object is accounted for: migrated, flagged, or dropped-with-reason.
- No generated DDL/DML is executed without human-confirm.
- Lossy and unsupported items are surfaced before sign-off.

## Provenance & governance
Never executes against a live target. Produces scripts + plan + risk report; all writes proposed and human-gated.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

