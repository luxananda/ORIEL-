---
name: catalog-export
description: Emit standardized metadata/rule/formula catalog entries and optionally write them back to Confluence or SharePoint. Use when the user wants to export the catalog or publish entries to a wiki/document store. Write-back requires explicit approval.
---

# Catalog Export

**Layer:** Serving (Layer H)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The publish step; turns ORIEL into the standardized artifacts other teams consume.

## When to use
`catalog export [--to confluence|sharepoint|file]`.

## Inputs
CatalogEntry and related nodes; a target (file or connector).

## Method
1. Render CatalogEntry nodes to the standardized shape (dataset, field, type, source, classification, status).
2. For file export, write locally. For Confluence/SharePoint write-back, prepare the change and require explicit human approval before publishing — never auto-publish.
3. Default to exporting confirmed entries; allow --status to widen with a warning.

## Output → ORIEL
A standardized catalog (file) or a prepared, approval-gated write-back.

## Quality bar
- Default export is confirmed-only.
- Write-back never proceeds without explicit approval.
- Exported entries match the standard shape exactly.

## Provenance & governance
Publishing is a side-effectful action: approval-gated, logged to the audit ledger.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

