---
name: identifier-rules-mapper
description: Apply target-dialect identifier rules — case-folding, reserved words, length limits, quoting, and schema/dataset namespacing — producing a safe, deterministic rename map that preserves business aliases. Use during migration to avoid invalid identifiers and name collisions.
---

# Identifier-Rules Mapper

**Layer:** Migration · Map  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Prevents the silent name breakage that derails migrations, while keeping every original name traceable as an alias.

## When to use
Map phase of `migrate`.

## Inputs
Object/column names from the harvest, plus the target Dialect.

## Composes (does not re-implement)
`entity-term-identifier`, `synonym-structural-refiner`

## Method
1. Detect reserved-word collisions and length-limit violations for the target dialect+version.
2. Apply the target's case-folding policy (Oracle uppercases unquoted; Postgres lowercases; BigQuery is case-sensitive) and quoting rules.
3. Resolve namespacing: Oracle schema.table, Postgres schema.table, BigQuery project.dataset.table.
4. Produce a deterministic rename map; preserve original names as SAME_AS aliases so lineage and the glossary survive.

## Output → ORIEL
`IdentifierMapping` nodes (source_name, target_name, reason) plus preserved aliases.

## Quality bar
- No reserved-word or length violations in target names.
- Renames deterministic and reversible.
- Original names retained as aliases.

## Provenance & governance
Non-trivial renames surfaced in the risk report for steward review.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

