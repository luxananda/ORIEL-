---
name: extract-data-metadata
description: Extract a full data-metadata catalog from a source: schema, keys/joins, mandatory vs optional fields, lineage, sensitive/regulated fields, and standardized catalog entries. Use when the user wants the data metadata, data dictionary, or catalog of a repo/folder/database/document.
---

# Extract Data Metadata

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Composes the metadata path of the engine end to end, writing a coherent data layer into ORIEL.

## When to use
`extract data-metadata <source>` or `run` with metadata requested.

## Inputs
Normalized blocks for a source.

## Composes (does not re-implement)
`entity-term-identifier`, `schema-extractor`, `key-join-detector`, `lineage-tracer`, `pii-sensitivity-classifier`

## Method
1. Run entity-term-identifier then schema-extractor for entities and fields.
2. Run key-join-detector for PK/FK/joins; mark mandatory vs optional from nullability.
3. Run lineage-tracer for source→transform→output; run pii-sensitivity-classifier for regulated fields.
4. Emit standardized CatalogEntry nodes (dataset, field, type, source, classification, status=proposed).

## Output → ORIEL
Entities, Fields, Keys, lineage edges, SensitivityTags, and CatalogEntry nodes.

## Quality bar
- Every field has type, nullability, lineage (or unresolved flag), and a sensitivity classification.
- Catalog entries conform to the standard shape.

## Provenance & governance
Composes primitives — does not re-implement them; all outputs proposed pending confirm.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

