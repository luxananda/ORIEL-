---
name: eql-orchestrator
description: Parse and execute EQL commands (run/extract/query/explain/catalog) over any source, planning and sequencing the extraction pipeline into the ORIEL graph. Use when the user types a datametadata/EQL command, asks to run metadata/rule/formula/workflow extraction over a repo, folder, document, or table, or asks to query/explain/catalog what was extracted.
---

# EQL Orchestrator

**Layer:** Orchestration (Layer D)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The router and entry point. Turns one declarative EQL verb into a sequenced plan over ingestion, normalization, the right extractors, the shared primitives they need, ORIEL writes, and indexing. Reads ORIEL_SCHEMA.md and EQL_SPEC.md (in this folder) as the canonical contract.

## When to use
The message is or contains an EQL command, or asks to extract/query/explain/catalog over a source. Always the first skill for a `run`.

## Inputs
An EQL command string and a `<source>` (repo URL, folder, document, table, or connector handle).

## Method
1. Parse the verb and arguments against EQL_SPEC.md; reject unknown verbs with the valid surface.
2. For `run`: plan ingest → detect → segment → normalize → (selected extractors) → graph-writer → three-index-builder. For `extract`: plan just that extractor + its primitives. For `query/explain`: route to the read skills only (never write).
3. Resolve the source via the appropriate connector (github / atlassian-rovo / sharepoint-odsp / database). If a connector is missing, stop and tell the user which to enable — never fabricate access.
4. Sequence extractors so shared primitives run once and are reused (e.g. if-then-normalizer feeds both domain-rules and workflow). Pass the run-id so every node is traceable to this invocation.
5. After extraction, trigger confidence-scorer and provenance-tagger as cross-cutting passes; surface a run summary (counts by node type, % proposed vs confirmed, low-confidence queue size).

## Output → ORIEL
No graph facts of its own. Emits a run manifest node referenced by EVIDENCED_BY on everything produced in the run.

## Quality bar
- Every planned step maps to a real skill; no orphan steps.
- `query`/`explain` plans contain zero write operations.
- Run summary always reports the proposed/confirmed split and the low-confidence count.

## Provenance & governance
Owns the run-id and ensures provenance is threaded through. Defaults all new facts to status=proposed.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

