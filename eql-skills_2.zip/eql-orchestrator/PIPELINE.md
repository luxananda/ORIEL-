# Pipeline (engine layers A–I, from the architecture)

A/B Ingestion & Storage   -> source-ingestor
C   Normalization         -> language-framework-detector, artifact-segmenter, normalizer
D   Agentic Router        -> eql-orchestrator
E/F Extraction & Canon.   -> 6 extractors + 12 shared primitives + ORIEL graph skills
G   Three-Index Strategy  -> three-index-builder
H   Serving               -> query-graph, view-glossary, catalog-export
I   Controls & Learning   -> provenance-tagger, confidence-scorer, human-confirm-gate, audit-ledger

Design law: DEPTH NOT BREADTH. One declarative command fronts a layered engine.
Extractors compose primitives; they do not re-implement them.
