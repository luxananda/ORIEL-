# EQL — Extraction Query Language (v0.1)

Declarative surface: express WHAT to extract or read, not HOW.
The `eql-orchestrator` parses these verbs and plans the pipeline.

## Verbs
```
run <source> [--extractors a,b,c] [--since <rev>]
    Full pipeline: ingest → normalize → route → extract → write ORIEL.
    Default extractors = all six. <source> = repo URL | doc | table | folder.

extract <type> <source>
    Single extractor. type ∈ {data-metadata, domain-rules, formulas,
    business-logic-workflow, calculation-logic, code-to-plain-english}.

query <view> [args]
    Read a view over ORIEL. view ∈ {rules, lineage <field>, entities,
    pii, formulas, workflows, glossary, catalog}. Read-only.

explain <ref> [--audience business|technical]
    Plain-English narrative for a node, file, or subgraph.

catalog export [--to confluence|sharepoint|file] [--status confirmed]
    Emit standardized catalog entries; optional write-back (needs approval).

confirm <node-id> | review [--low-confidence] [--domain X]
    Governance: ratify proposed nodes; route low-confidence for review.

diff <source> --from <rev> --to <rev>
    Bi-temporal change report between two source versions.
```

## Examples
```
datametadata run github.com/langchain-ai/langgraph
datametadata extract domain-rules ./loan_service/
datametadata query rules --domain risk
datametadata query lineage CustID
datametadata explain ./pricing.py --audience business
datametadata catalog export --to confluence --status confirmed
```

## Routing
`run` → ingest (source-ingestor) → detect (language-framework-detector) →
segment (artifact-segmenter) → normalize (normalizer) → for each requested
extractor, the extractor calls the shared primitives it needs → ORIEL
(graph-writer) → index (three-index-builder). Governance skills run as
cross-cutting passes. Views read; they never write graph facts.


## Migration verb (added by the Migration Pack)
```
migrate <source> --to <dialect>[@version] [--objects tables,views,procs,triggers]
                  [--data plan] [--from <dialect>]
    Harvest <source> into ORIEL (dialect-neutral), map types/features/identifiers
    to the target, generate target DDL/DML + a data-movement plan, then validate
    equivalence and emit a risk report. Generates artifacts; never executes them.

Examples:
  datametadata migrate ./schema.sql --to oracle@19c
  datametadata migrate postgres://prod/app --to bigquery --objects tables,views --data plan
  datametadata migrate oracle://erp --to bigquery --objects tables,procs
```


## Reference & North-Star verbs (added by the Reference & North-Star Pack)
```
benchmark <source> --against <reference>[@version] [--domain X]
    Load the reference, crosswalk our model to it, and produce a gap analysis
    + conformance score. Read/analysis; writes proposed crosswalk and gap nodes.

northstar <domain> --reference <reference> [--layer ontology|data-model|data-architecture|metadata-tom]
    Build the opinionated, bank-specific target at the chosen layer, with design
    decisions for every deviation, plus a sequenced roadmap from current to target.

glossary import <file.xlsx> | glossary export [--to xlsx]
    Excel round-trip: import a legacy glossary as current state; export the governed
    glossary (or gap-analysis / north-star) as a steward-ready workbook.

Examples:
  datametadata benchmark ./customer_domain --against fibo@2026Q1 --domain customer
  datametadata northstar customer --reference fibo --layer data-model
  datametadata glossary import ./legacy_glossary.xlsx
  datametadata glossary export --to xlsx
```
