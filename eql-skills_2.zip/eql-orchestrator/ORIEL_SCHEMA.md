# ORIEL — Graph Contract (v0.1)

ORIEL is the single labelled-property graph every EQL skill reads from and writes to.
"Extract once, serve many" only holds if every skill conforms to this contract.

## Node types
| Node | Key attributes |
|---|---|
| `SourceArtifact` | uri, kind (code/doc/table/api/stream), version|commit_sha, ingested_at |
| `Entity` | name, aliases[], domain[] |
| `Field` | name, datatype, nullable(bool), parent_entity |
| `Key` | kind (PK/FK/UNIQUE), field_ref, references (entity.field) |
| `Rule` | condition, action, polarity (positive/negative), domain[] |
| `ImplicitRule` | kind (default/fallback/assumption), statement |
| `Formula` | expression, output_field, variables[], constants[], precision, rounding, units |
| `FormulaVariant` | base_formula_ref, expression, applies_when |
| `Workflow` | name, states[], decision_points[] |
| `WorkflowPath` | workflow_ref, sequence[], kind (standard/variant/fallback) |
| `Qualifier` | kind (region/product/policy/temporal), value |
| `SensitivityTag` | classification (PII/SPI/regulated/public), regulation[] |
| `AtomicProposition` | text, parent_ref (indivisible logical unit) |
| `PlainEnglish` | target_ref, text, audience (technical/business) |
| `CatalogEntry` | dataset, field, datatype, source, classification, status |

## Edge types
| Edge | From → To | Meaning |
|---|---|---|
| `HAS_FIELD` | Entity → Field | structure |
| `KEY_OF` | Key → Field | primary/foreign/unique key |
| `DERIVES_FROM` | Field/Formula → Field/SourceArtifact | lineage: source → transform → output |
| `CONSTRAINS` | Rule → Field/Entity | a rule limits a field/entity |
| `TRIGGERS` | Rule → FormulaVariant/WorkflowPath | rule selects a variant/branch |
| `GOVERNED_BY` | FormulaVariant/WorkflowPath → Rule | inverse of TRIGGERS |
| `QUALIFIED_BY` | any → Qualifier | region/product/policy/temporal scope |
| `TAGGED` | Field/any → SensitivityTag | sensitivity / regulation |
| `DECOMPOSES_TO` | Rule/Workflow/table → AtomicProposition | atomic decomposition |
| `SAME_AS` | any → any | synonym / canonical merge |
| `DESCRIBES` | PlainEnglish → any | narrative attached to a node |
| `EVIDENCED_BY` | any node → SourceArtifact | **provenance: where this came from** |

## Provenance block (REQUIRED on every node and edge)
```
provenance:
  source_uri:   <repo/doc/table uri>
  locator:      <file:line-range | doc§ | sheet!cell | api#operation>
  version:      <commit_sha | doc_version | snapshot_id>
  extractor:    <skill-name@version>
  extracted_at: <ISO-8601>
  confidence:   <0.0–1.0>
  status:       proposed | confirmed | rejected
  confirmed_by: <user|null>
  confirmed_at: <ISO-8601|null>
```

## Bi-temporal block (REQUIRED on every node and edge)
```
temporal:
  valid_from:    <business-time start>      # when the fact is true in the world
  valid_to:      <business-time end|null>
  recorded_from: <system-time start>        # when EQL recorded it
  recorded_to:   <system-time end|null>     # null = current; non-null = superseded
```
Never hard-delete. Supersede by closing `recorded_to` and writing a new version.

## Hard rules
1. No node or edge without a complete provenance + temporal block.
2. Nothing is `confirmed` by an extractor — only a human, via `human-confirm-gate`.
3. Default status is `proposed`. Views may flag proposed-only results.
4. All ids are stable, content-addressed where possible, so re-runs are idempotent.


## Migration extension (v0.1)
Added by the EQL Migration Pack. Same provenance + bi-temporal rules apply.

| Node | Key attributes |
|---|---|
| `Dialect` | name, version, confidence |
| `TypeMapping` | source_type, canonical_type, target_type, lossy(bool), note |
| `FeatureMapping` | feature, target_equivalent\|workaround, manual(bool), note |
| `IdentifierMapping` | source_name, target_name, reason |
| `StoredLogic` | kind (view/proc/func/trigger/package), signature, body, dependencies[] |
| `GeneratedArtifact` | dialect, kind (ddl/dml/routine), sql_text, realizes[] |
| `MigrationPlan` | steps[], transforms[], strategy (bulk/CDC) |
| `MigrationRisk` | item, kind (lossy/unsupported/manual), impact, mitigation |

| Edge | From → To | Meaning |
|---|---|---|
| `MAPS_TO` | Field/feature/name → TypeMapping/FeatureMapping/IdentifierMapping | translation record |
| `REALIZES` | GeneratedArtifact → source Entity/Field/Key | this artifact recreates that object |
| `TRANSLATES` | GeneratedArtifact → StoredLogic | translated routine |
| `VALIDATES` | equivalence/risk report → migration manifest | validation linkage |

Hard rule: `GeneratedArtifact` SQL is never executed by any skill. Only a human,
via `human-confirm-gate`, may authorise running it against a target.


## Reference & North-Star extension (v0.1)
Added by the EQL Reference & North-Star Pack. Same provenance + bi-temporal rules apply.

| Node | Key attributes |
|---|---|
| `ReferenceModel` | standard (FIBO/ISO20022/BIAN/FIB-DM), publisher, version |
| `ReferenceConcept` | label, definition, relationships[] (tagged as reference, never our fact) |
| `Crosswalk` | our_concept, ref_concept, relation (exact/broader/narrower/related/none), confidence, evidence |
| `GapItem` | kind (missing/divergent/extra/structural), severity, recommendation, domain |
| `ConformanceScore` | domain, coverage_pct, alignment_score |
| `NorthStarModel` | layer (ontology/data-model/data-architecture/metadata-tom), targets[] |
| `DesignDecision` | principle, decision, rationale, deviates_from_ref(bool) |
| `RoadmapItem` | wave, dependency[], effort, impact |

| Edge | From → To | Meaning |
|---|---|---|
| `ALIGNS_TO` | our concept/Term/Entity → ReferenceConcept | crosswalk alignment (with relation) |
| `GAP_AGAINST` | GapItem → ReferenceConcept/our node | what the gap is measured against |
| `TARGETS` | NorthStarModel node → current node / GapItem | the target for a current concept/gap |
| `DECIDES` | DesignDecision → NorthStarModel node | rationale for a target / a deviation |
| `SEQUENCED_AS` | RoadmapItem → GapItem | how a gap is scheduled |

Hard rule: a reference is a **benchmark, not an authority**. ReferenceConcepts never
overwrite our concepts; every north-star deviation from the reference is recorded as a
DesignDecision. Our business names stay primary; reference labels are cross-references.
