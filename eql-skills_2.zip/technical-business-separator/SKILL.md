---
name: technical-business-separator
description: Separate incidental technical conditions (null guards, type checks, plumbing) from genuine business intent within rules and workflows. Use when extracting rules, workflows, or business logic so the catalog reflects intent, not implementation noise.
---

# Technical/Business Separator

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Keeps ORIEL's rule layer business-meaningful; demotes plumbing so views aren't polluted.

## When to use
After if-then-normalizer; used by rule, workflow, and business-logic extractors.

## Inputs
Rule nodes and their context.

## Method
1. Classify each rule/condition as business-intent or technical-condition using surrounding entities and effects.
2. Mark technical conditions as supporting, not primary; keep them linked but out of business views by default.
3. Where a technical check encodes a business constraint (e.g. amount > 0), promote it to business with a note.

## Output → ORIEL
A business/technical flag on each Rule; technical ones demoted in views.

## Quality bar
- Business rules are not buried under plumbing.
- Borderline cases promoted with justification, not dropped.

## Provenance & governance
Reclassifications are recorded so a reviewer can audit the call.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

