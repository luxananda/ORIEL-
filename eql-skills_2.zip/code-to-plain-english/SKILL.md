---
name: code-to-plain-english
description: Convert code into a plain-English business narrative: identify entry points, detect language/framework, segment into blocks, map data flow and side effects, translate control flow, explain data structures in human terms, generate a step-by-step narrative, and summarize purpose in one business sentence. Use when the user wants to understand what code does in plain language.
---

# Code → Plain English

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Composes the narration path; the most-used standalone view skill.

## When to use
`explain <code>` / `extract code-to-plain-english <source>`.

## Inputs
Normalized code blocks.

## Composes (does not re-implement)
`language-framework-detector`, `artifact-segmenter`, `plain-english-translator`

## Method
1. Identify entry points (main/APIs/jobs/scripts) and detect language/framework.
2. Map inputs, outputs, and side effects per block; translate control flow (if/else, loops, exceptions) into prose.
3. Explain data structures in human terms; generate a step-by-step narrative.
4. Close with a single business-facing purpose sentence.

## Output → ORIEL
`PlainEnglish` nodes (step narrative + one-line purpose) DESCRIBES the code.

## Quality bar
- Purpose sentence is business-facing, not technical.
- Side effects (DB/logs/external calls) are named.
- Narrative is intent-first, not a line echo.

## Provenance & governance
Narrative confidence reflects detection confidence of the code.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

