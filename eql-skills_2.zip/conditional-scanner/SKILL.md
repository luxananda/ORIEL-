---
name: conditional-scanner
description: Scan code and docs for conditional statements, validations, guards, and branching that encode rules. Use as the first step of rule, workflow, or formula-variation extraction.
---

# Conditional Scanner

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Finds the raw conditional material that if-then-normalizer turns into rules.

## When to use
Feeds extract-domain-rules, extract-business-logic-workflow, and formula-variant detection.

## Inputs
Normalized code/doc blocks.

## Method
1. Locate if/else, switch, guard clauses, validation calls, and 'shall/must/if…then' patterns in prose.
2. Capture the condition, the consequent, and the source locator verbatim.
3. Hand each raw conditional to if-then-normalizer; do not normalize here.

## Output → ORIEL
Raw conditional records (condition, consequent, locator) staged for normalization.

## Quality bar
- Negations and compound conditions captured intact.
- No silent dropping of else/default branches.

## Provenance & governance
Each raw conditional retains its exact locator.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

