---
name: definition-harmonizer
description: Reconcile our business definitions against the reference definitions — flag conflicts, redundancy, and ambiguity, and propose a harmonized definition that keeps our context while aligning to the standard. Use during benchmarking to raise definition quality and consistency.
---

# Definition Harmonizer

**Layer:** Reference · Alignment  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Lifts definition quality using the reference as a yardstick, without erasing bank-specific meaning.

## When to use
Alignment step, after the crosswalk.

## Inputs
Aligned glossary terms (ours) and their reference definitions.

## Composes (does not re-implement)
`plain-english-translator`

## Method
1. For each aligned term, compare our definition with the reference; classify as consistent / divergent / missing / conflicting.
2. Where divergent, propose a harmonized definition that preserves our context and notes the deviation from the standard.
3. Flag genuine conflicts (same term, incompatible meaning) for steward resolution.

## Output → ORIEL
Harmonized definition proposals + a definition-conflict list, attached to glossary terms.

## Quality bar
- Divergences explained, not auto-overwritten.
- Conflicts surfaced for humans.
- Bank context retained.

## Provenance & governance
Definition changes are steward-confirmed; deviations from the standard carry a recorded rationale.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

