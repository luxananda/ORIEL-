---
name: reference-crosswalk-mapper
description: Map our entities, terms, and data model to an industry reference (FIBO / ISO 20022 / BIAN), classifying each alignment as exact, broader, narrower, related, or no-match, and preserving our names as aliases. Use to benchmark our model against a standard or to prepare a gap analysis.
---

# Reference Crosswalk Mapper

**Layer:** Reference · Alignment  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The alignment heart. Builds the crosswalk that gap analysis and the north-star both depend on.

## When to use
Alignment step of `benchmark`/`northstar`.

## Inputs
Our concepts/terms/entities and a loaded ReferenceModel.

## Composes (does not re-implement)
`synonym-structural-refiner`, `entity-term-identifier`

## Method
1. For each of our concepts, find candidate reference concepts by lexical, structural and definitional similarity.
2. Classify the relation (SKOS-style): exact / broader / narrower / related / no-match, with the evidence for the call.
3. Record an ALIGNS_TO edge; keep our label as the alias so lineage and the glossary survive.
4. Leave low-confidence matches unconfirmed for steward review rather than forcing an alignment.

## Output → ORIEL
`Crosswalk` / ALIGNS_TO edges (our concept → reference concept, relation, confidence, evidence).

## Reference notes
Relations follow SKOS semantics: exactMatch ≠ broadMatch ≠ narrowMatch ≠ relatedMatch. A 'related' match is not equivalence — it must not be treated as one downstream.

## Quality bar
- Relations are precise (exact ≠ broader ≠ related).
- No forced matches.
- Our names preserved as aliases.

## Provenance & governance
Alignments proposed; steward confirms; the reference never overwrites our concept.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

