---
name: language-framework-detector
description: Detect the programming language(s), framework(s), and document type of each ingested artifact to route it to the right parser and extractor. Use during `run`/`extract` after ingestion, or when an artifact's type is ambiguous.
---

# Language & Framework Detector

**Layer:** Normalization (Layer C)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Classifies each SourceArtifact so segmentation and extraction use the correct grammar (Python vs Java vs SQL vs prose vs spreadsheet).

## When to use
Immediately after source-ingestor, before segmentation.

## Inputs
SourceArtifact nodes.

## Method
1. Infer language from extension, shebang, and content signatures; infer framework from imports/manifests (e.g. requirements.txt, pom.xml, package.json).
2. Classify documents: prose, spec, spreadsheet/table, API definition, config.
3. Attach a confidence to each classification; ambiguous artifacts (mixed content) get multiple labels.

## Output → ORIEL
Annotates each `SourceArtifact` with language[], framework[], doc_type, each carrying confidence.

## Quality bar
- Mixed-content artifacts are multi-labelled, not forced into one bucket.
- Low-confidence detections are flagged for the segmenter to treat conservatively.

## Provenance & governance
Detection confidence propagates; it caps the confidence of anything later extracted from that artifact.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

