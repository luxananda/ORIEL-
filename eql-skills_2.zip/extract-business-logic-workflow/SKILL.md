---
name: extract-business-logic-workflow
description: Extract end-to-end business workflows with domain-rule linkage: process flow, decision points/branches, governing rules per branch, region/product/policy deviations, optional/skipped/substituted steps, rule-driven external interactions, state transitions, and fallbacks. Use when the user wants the process/workflow logic of a source.
---

# Extract Business-Logic Workflow

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Composes flow analysis with rule linkage into workflow variants in ORIEL.

## When to use
`extract business-logic-workflow <source>` or `run`.

## Inputs
Normalized code/doc blocks describing processes.

## Composes (does not re-implement)
`conditional-scanner`, `if-then-normalizer`, `qualifier-resolver`, `technical-business-separator`, `plain-english-translator`, `domain-tagger`

## Method
1. Identify the end-to-end flow and decision points; use if-then-normalizer for branch conditions.
2. Link each workflow path to its governing rule(s); resolve region/product/policy deviations via qualifier-resolver.
3. Detect optional/skipped/substituted steps and rule-driven external interactions (APIs, DBs); capture state transitions per variant.
4. Identify fallback paths for unmet conditions; translate each variant to plain English.

## Output → ORIEL
`Workflow` and `WorkflowPath` nodes, decision points, GOVERNED_BY edges, qualifiers, state transitions, plain-English.

## Quality bar
- Every branch links to a governing rule.
- Variants and fallbacks captured per qualifier.
- External interactions recorded with their triggering rule.

## Provenance & governance
Paths proposed; deviations evidenced by the qualifier that scopes them.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

