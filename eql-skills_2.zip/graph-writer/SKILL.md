---
name: graph-writer
description: Persist extracted nodes and edges into the ORIEL graph with full provenance and bi-temporal versioning, idempotently. Use as the write step of any extraction; the only skill permitted to mutate graph facts.
---

# Graph Writer

**Layer:** ORIEL Graph  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The sole writer to ORIEL; enforces the contract so the graph stays trustworthy.

## When to use
After extractors/refiners produce nodes and edges.

## Inputs
Proposed nodes and edges from extraction skills.

## Method
1. Validate every node/edge against ORIEL_SCHEMA.md; reject any missing provenance or temporal blocks.
2. Upsert idempotently by stable id; on change, close the prior version's recorded_to and write a new version (never hard-delete).
3. Set valid_from/valid_to from qualifiers/effective dates; set recorded_from to now.

## Output → ORIEL
Committed ORIEL nodes/edges with closed-loop bi-temporal versioning.

## Quality bar
- No write without complete provenance + temporal blocks.
- Re-running an unchanged extraction is a no-op.
- History preserved by supersession, never deletion.

## Provenance & governance
The contract chokepoint: status defaults to proposed; only human-confirm-gate flips to confirmed.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

