---
name: synonym-structural-refiner
description: Eliminate redundancy in the graph by clustering synonyms and pruning structurally duplicate nodes/edges, merging aliases into canonical nodes. Use after extraction to deduplicate entities, terms, and rules before serving.
---

# Synonym & Structural Refiner

**Layer:** ORIEL Graph  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Stage 3 of ORIEL construction; collapses the alias clutter into canonical concepts.

## When to use
After decomposition, before indexing/serving.

## Inputs
Candidate SAME_AS clusters from entity/term identification and rules.

## Method
1. Cluster synonyms (lexical + structural similarity); choose a canonical node per cluster.
2. Merge via SAME_AS, redirecting edges to the canonical node; prune duplicate edges.
3. Never merge across distinct domains/qualifiers without explicit evidence.

## Output → ORIEL
Canonicalized nodes with SAME_AS provenance; a leaner, non-redundant graph.

## Quality bar
- No semantically distinct nodes merged.
- Every merge is reversible (SAME_AS retained, originals not destroyed).

## Provenance & governance
Merges are proposed and reversible; ambiguous merges route to review.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

