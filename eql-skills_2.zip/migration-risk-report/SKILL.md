---
name: migration-risk-report
description: Produce the migration gap/risk report — lossy type conversions, unsupported features, manual-rewrite items, truncation/precision risks, and index/performance gaps — prioritized, bank-grade, and gated by human review. Use to surface everything a migration could break before anyone runs it.
---

# Migration Risk Report

**Layer:** Migration · Validate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
The controls artifact for migration: the go/no-go evidence pack.

## When to use
Validate phase of `migrate`; before any execution.

## Inputs
All TypeMappings, FeatureMappings, IdentifierMappings, and stored-logic manual items.

## Composes (does not re-implement)
`type-system-mapper`, `feature-equivalence-mapper`, `stored-logic-translator`

## Method
1. Aggregate lossy type conversions, unsupported features, manual stored-logic rewrites, and non-trivial identifier renames.
2. Rate each item by impact and likelihood; recommend a concrete mitigation.
3. Compile a prioritized report and route the whole thing through human-confirm.

## Output → ORIEL
`MigrationRisk` nodes + a prioritized report; logged to the audit-ledger.

## Quality bar
- Every lossy/unsupported/manual item appears with impact + mitigation.
- Nothing is marked migrated until its risks are acknowledged.
- Report is prioritized, not a flat dump.

## Provenance & governance
Human-confirm gated; this report is the go/no-go gate for the migration.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

