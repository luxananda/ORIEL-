---
name: northstar-data-model-builder
description: Build the target (north-star) data model — conceptual → logical → physical entities, attributes, keys and relationships — reference-aligned and bank-specific, ready to guide implementation. Use to set the structural target for the data estate.
---

# North-Star Data-Model Builder

**Layer:** Reference · North-Star  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The structure-layer north-star: the implementable target.

## When to use
North-star step, data-model layer.

## Inputs
The north-star ontology, our current model, and any reference data model (e.g. FIB-DM).

## Composes (does not re-implement)
`northstar-ontology-modeler`, `schema-extractor`, `key-join-detector`

## Method
1. Project the north-star ontology into a logical data model (entities, attributes, keys, relationships, cardinality).
2. Where a reference data model exists (e.g. FIB-DM), align to it and note deviations.
3. Add physical considerations only where they are target-defining (naming standards, surrogate keys, partitioning); leave platform specifics to migration.
4. Capture conceptual → logical → physical lineage so each target entity traces to its concept.

## Output → ORIEL
A `NorthStarModel` (layer=data-model) with conceptual/logical/physical entities + key/relationship structure.

## Quality bar
- Every target entity traces to a north-star concept.
- Keys and relationships explicit.
- Reference alignment recorded.

## Provenance & governance
Proposed; deviations carry design decisions; architecture sign-off before it guides build.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

