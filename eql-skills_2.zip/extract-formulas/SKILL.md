---
name: extract-formulas
description: Extract mathematical formulas and derived fields with domain-rule linkage: base structure, variables/constants, conditional variations, the rules that trigger each variant, lineage of derived variables, qualifiers, and plain-English. Use when the user wants the formulas, calculations, or derived-field logic of a source.
---

# Extract Formulas & Calculations

**Layer:** Extractor  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Composes formula detection with rule linkage and lineage, producing a context-aware formula catalog.

## When to use
`extract formulas <source>` or `run`.

## Inputs
Normalized code/spreadsheet/doc blocks.

## Composes (does not re-implement)
`conditional-scanner`, `if-then-normalizer`, `qualifier-resolver`, `lineage-tracer`, `implicit-rule-detector`, `plain-english-translator`, `domain-tagger`

## Method
1. Detect expressions and derived fields; capture base structure, variables, and constants.
2. Detect conditional variations; use if-then-normalizer + qualifier-resolver to bind each variant to its triggering rule and context (region/product/policy/temporal).
3. Resolve variables to raw sources via lineage-tracer; capture fallback/default calculations via implicit-rule-detector.
4. Translate each variant to plain English; emit a formula catalog with context-specific variants.

## Output → ORIEL
`Formula` and `FormulaVariant` nodes, GOVERNED_BY/TRIGGERS edges to rules, DERIVES_FROM lineage, qualifiers, plain-English.

## Quality bar
- Each variant linked to its triggering rule and qualifying context.
- Variables resolved to raw sources or flagged unresolved.
- Fallback/default calculations captured.

## Provenance & governance
Variants proposed; rule linkage evidenced both ways.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

