---
name: entity-term-identifier
description: Identify business-specific entities and domain terms (e.g. Customer, Loan, Risk, Product) and their aliases across code and docs. Use whenever an extractor needs the business vocabulary, or the user asks for the entities/glossary of a source.
---

# Entity & Term Identifier

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Establishes the noun layer of ORIEL that rules, fields, and formulas attach to.

## When to use
Called by most extractors; directly invocable for 'what entities/terms exist here'.

## Inputs
Normalized blocks.

## Method
1. Extract candidate entities from identifiers, table names, doc headings, and recurring capitalized domain nouns.
2. Cluster aliases (CustID, customer_id, Customer) as candidates for SAME_AS, deferring the merge to synonym-structural-refiner.
3. Tag each entity with a provisional domain (finance/customer/product/risk) for domain-tagger to confirm.

## Output → ORIEL
`Entity` nodes with aliases[]; HAS_FIELD edges created later by schema-extractor.

## Quality bar
- Aliases proposed, not silently merged.
- No generic programming terms misclassified as business entities.

## Provenance & governance
Each entity EVIDENCED_BY the blocks it was seen in.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

