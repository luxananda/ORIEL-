---
name: normalizer
description: Clean and canonicalize block content (whitespace, encoding, comment/code separation, terminology casing) into a stable form so extraction is consistent across sources. Use during `run`/`extract` after segmentation.
---

# Normalizer

**Layer:** Normalization (Layer C)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Removes incidental variation so the same logic in two files produces the same extracted facts.

## When to use
After artifact-segmenter, before extractors.

## Inputs
Block descriptors.

## Method
1. Normalize encoding/whitespace; separate comments and docstrings from executable code for parallel use.
2. Canonicalize obvious term variants (case, separators) without inventing meaning; record the mapping.
3. Preserve the original text and locator alongside the normalized form.

## Output → ORIEL
A normalized view per block, linked to the original; never overwrites source text.

## Quality bar
- Original text is always recoverable.
- Normalization never alters semantics, only form.

## Provenance & governance
The original-text link guarantees provenance survives normalization.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

