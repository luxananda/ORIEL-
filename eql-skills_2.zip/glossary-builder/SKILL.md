---
name: glossary-builder
description: Assemble and curate the governed business glossary in ORIEL — terms, definitions, synonyms/aliases, owners, domains, status, and links to the entities and reference concepts they denote. Use to build or maintain the authoritative business glossary from extracted entities, imported terms, and industry-reference seeds.
---

# Business Glossary Builder

**Layer:** Reference · Current-State  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The core glossary capability. The authoritative glossary lives in the graph; Excel is the interface.

## When to use
Building/maintaining the glossary; seeding from a reference.

## Inputs
Extracted entities, imported terms, and (optionally) reference concepts.

## Composes (does not re-implement)
`entity-term-identifier`, `plain-english-translator`, `domain-tagger`

## Method
1. Assemble candidate terms from extracted entities, the imported glossary, and reference seeds; one canonical term per concept, others as aliases.
2. Draft or curate a business definition (plain-english-translator); assign owner and domain; set status (proposed/approved/deprecated).
3. Link each term to the ORIEL entity it denotes and to its aligned reference concept, if any.
4. Keep our business name as the primary label; reference labels are cross-references, never replacements.

## Output → ORIEL
Governed glossary `Term` nodes (definition, owner, domain, status, aliases) linked to entities and reference concepts.

## Quality bar
- One canonical term per concept.
- Every term has a definition and an owner before approval.
- Our names primary; reference names cross-referenced.

## Provenance & governance
Status transitions (approved/deprecated) go through human-confirm; owner required to approve.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

