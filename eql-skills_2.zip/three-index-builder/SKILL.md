---
name: three-index-builder
description: Build three complementary indices over ORIEL — structural (graph topology), semantic (embeddings/meaning), and lexical (keywords) — so views and queries retrieve precisely. Use after graph writes, before serving, to make the graph queryable.
---

# Three-Index Builder

**Layer:** ORIEL Graph (Layer G)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The retrieval layer; makes 'extract once, serve many' fast and accurate.

## When to use
After graph-writer; refreshed on graph change.

## Inputs
The committed ORIEL graph.

## Method
1. Build a structural index over node/edge topology for traversal (lineage, governance chains).
2. Build a semantic index over node text/narratives for meaning-based retrieval.
3. Build a lexical index over names/aliases/terms for exact and fuzzy keyword lookup.

## Output → ORIEL
Three indices keyed to current node versions, used by query-graph.

## Quality bar
- Indices reference current (non-superseded) versions.
- Each query type routes to the index that serves it best.

## Provenance & governance
Indices respect status; views can restrict to confirmed-only.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

