---
name: if-then-normalizer
description: Normalize raw conditionals and validations into canonical IF condition THEN action rules, handling compound logic, negation, ranges, null/format checks, and defaults. Use whenever rules must be made uniform across sources — central to domain-rule, workflow, and formula extraction.
---

# IF–THEN Normalizer

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The canonical rule form the whole engine shares. Built once, reused by many extractors.

## When to use
After conditional-scanner; invoked by multiple extractors.

## Inputs
Raw conditional records.

## Method
1. Rewrite each conditional to `IF <condition> THEN <action>`; decompose compound conditions into explicit AND/OR trees.
2. Normalize comparisons (ranges → MIN/MAX, formats → pattern, null checks → presence) and make negation explicit (polarity).
3. Lift literals to named thresholds where a constant has business meaning (e.g. 700 → credit_score_threshold).
4. Preserve else/default branches as separate rules; never merge distinct actions.

## Output → ORIEL
`Rule` nodes (condition, action, polarity) ready for domain tagging and linkage.

## Quality bar
- Compound conditions are explicit trees, not flattened strings.
- Every branch, including default, becomes a rule.
- Thresholds named where meaningful, with the raw literal retained.

## Provenance & governance
Each rule EVIDENCED_BY its source conditional; confidence reflects parse certainty.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

