---
name: ontology-modeler
description: Model extracted entities and their relationships into a hierarchical ontology (parent/child/sibling/attribute) over the ORIEL graph. Use when the user wants the ontology, taxonomy, or conceptual model of a source, or to structure entities before serving views.
---

# Ontology Modeler

**Layer:** ORIEL Graph  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Stage 1 of the ORIEL construction pipeline; imposes hierarchy on the entity layer.

## When to use
After entity/field extraction; supports `query ontology`.

## Inputs
Entity, Field, and Key nodes.

## Method
1. Derive parent/child relationships from keys, containment, and naming hierarchy; place fields as attributes.
2. Identify sibling sets and abstract shared parents where justified.
3. Keep the ontology evidence-linked — no concept without a source.

## Output → ORIEL
Hierarchy edges over entities/fields forming a navigable ontology.

## Quality bar
- Every concept traces to evidence.
- Hierarchy reflects real keys/containment, not guessed taxonomy.

## Provenance & governance
Abstractions are flagged as inferred for review.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

