---
name: domain-tagger
description: Tag rules, fields, formulas, and workflows by business domain (finance, customer, product, risk, etc.). Use during any extraction, or when the user wants to filter the catalog/rules by domain.
---

# Domain Tagger

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Adds the domain facets that make `query rules --domain risk` work.

## When to use
Across extractors; supports domain-scoped views.

## Inputs
Rule/Field/Formula/Workflow nodes plus their entities.

## Method
1. Assign domain tags from linked entities, vocabulary, and module/path context.
2. Allow multiple domains per node; record the evidence for each tag.

## Output → ORIEL
TAGGED edges to a controlled domain vocabulary on each node.

## Quality bar
- Domain vocabulary is controlled, not free-text.
- Multi-domain nodes allowed; each tag evidenced.

## Provenance & governance
Tags carry confidence; weakly-evidenced tags surface in review.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

