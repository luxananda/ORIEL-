---
name: roadmap-sequencer
description: Sequence the gap backlog into a phased roadmap from current state to the north-star — waves, dependencies, quick wins versus foundational work — prioritized by effort and impact. Use to turn a gap analysis and north-star into an actionable plan.
---

# Roadmap Sequencer

**Layer:** Reference · Roadmap  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Makes the north-star real. Without it, the north-star is a poster.

## When to use
After gap analysis and north-star definition.

## Inputs
The gap register and the north-star targets.

## Composes (does not re-implement)
`gap-analyzer`

## Method
1. Cluster gap items into coherent workstreams.
2. Order by dependency (foundational concepts/keys before dependents) and value (regulatory and quick-win first).
3. Group into phases/waves with entry/exit criteria; flag dependencies and risks.
4. Estimate relative effort and impact per item for prioritization.

## Output → ORIEL
`RoadmapItem` nodes (wave, dependency, effort, impact) forming a sequenced plan current → north-star.

## Quality bar
- Dependency-respecting order.
- Quick wins separated from foundational work.
- Each item ties to a gap and a north-star target.

## Provenance & governance
Proposed; sequencing reviewed by the data council before commitment.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

