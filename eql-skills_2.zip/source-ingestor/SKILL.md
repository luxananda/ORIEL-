---
name: source-ingestor
description: Pull raw artifacts (code, docs, API specs, table/DDL, streams) from a source or connector and register each as a SourceArtifact with version/commit provenance. Use when EQL needs to read a repo, folder, Confluence/SharePoint space, or database before extraction can begin.
---

# Source Ingestor

**Layer:** Ingestion (Layers A/B)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
First hands-on step of `run`. Materializes the source into a normalized set of SourceArtifact nodes the rest of the engine works on.

## When to use
A `run` or `extract` references a source not yet ingested in this run.

## Inputs
A `<source>` and the connector that reaches it (github / atlassian-rovo / sharepoint-odsp / database / local folder).

## Method
1. Enumerate artifacts under the source (files, pages, tables, API operations); skip binaries and vendored/third-party paths unless asked.
2. For each artifact capture uri, kind, and an immutable version handle: commit_sha for git, doc_version/page_id for Confluence/SharePoint, snapshot id for tables.
3. Record byte size and detected MIME; defer parsing to artifact-segmenter.
4. Respect connector permissions exactly as returned — never widen scope; if access is denied, report it rather than guessing content.

## Output → ORIEL
One `SourceArtifact` node per artifact, each with full provenance (version pinned) and an open bi-temporal record.

## Quality bar
- Every artifact has an immutable version handle.
- No artifact ingested outside the granted permission scope.
- Re-ingesting an unchanged version is idempotent (same ids).

## Provenance & governance
Provenance.version is mandatory and pinned here; downstream skills inherit it.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

