---
name: stored-logic-harvester
description: Extract views, materialized views, stored procedures, functions, triggers, and packages (e.g. Oracle PL/SQL, Postgres PL/pgSQL) into ORIEL with their dependencies and intent. Use when a migration must carry server-side/procedural logic, not just tables.
---

# Stored-Logic Harvester

**Layer:** Migration · Harvest  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Captures the procedural half of a schema that pure DDL harvesting misses — usually where the hardest migration work lives.

## When to use
Harvest phase of `migrate` when the source has views/procedures/triggers.

## Inputs
DDL/source for routines and views.

## Composes (does not re-implement)
`code-to-plain-english`, `conditional-scanner`

## Method
1. Locate view / materialized-view / procedure / function / trigger / package definitions; capture signature and body.
2. Build dependency edges to the tables and other routines each object references (for generation ordering).
3. Summarise intent with code-to-plain-english so the translator preserves meaning, not just syntax.
4. Flag dialect-specific constructs (PL/SQL packages, autonomous transactions, BULK COLLECT, cursors) for stored-logic-translator.

## Output → ORIEL
`StoredLogic` nodes (kind, signature, body, dependencies, plain-English) linked to the objects they touch.

## Quality bar
- Dependency edges captured so generation can order objects correctly.
- Dialect-specific constructs flagged, not hidden.
- Intent summarised for translation fidelity.

## Provenance & governance
Routine bodies retained verbatim with provenance; intent summaries inherit body confidence.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

