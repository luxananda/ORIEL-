---
name: provenance-tagger
description: Stamp every node and edge with complete provenance — source uri, locator, version/commit, extractor, timestamp — and verify nothing enters ORIEL unprovenanced. Use as a cross-cutting pass during every extraction run.
---

# Provenance Tagger

**Layer:** Controls (Layer I)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Guarantees the audit trail that makes ORIEL usable in a regulated environment.

## When to use
Cross-cutting during `run`/`extract`, before graph-writer commits.

## Inputs
Proposed nodes/edges plus run context.

## Method
1. Fill and verify the provenance block on every node/edge from segmenter locators and ingestor versions.
2. Reject anything that cannot be traced to a SourceArtifact + locator; route rejects back with a reason.
3. Thread the run-id so every fact links to the invocation that produced it.

## Output → ORIEL
Complete EVIDENCED_BY links and provenance blocks on all run output.

## Quality bar
- Zero unprovenanced facts reach graph-writer.
- Every fact links to source uri, locator, and version.

## Provenance & governance
The precondition for graph-writer; no provenance, no commit.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

