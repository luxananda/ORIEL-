---
name: industry-reference-loader
description: Load an industry reference model into ORIEL as a benchmark — FIBO (OWL ontology), ISO 20022 (data dictionary / metamodel), BIAN (service landscape / metamodel), or FIB-DM (FIBO-derived data model) — with its version, concepts, definitions and relationships. Use to bring an industry standard in for benchmarking, seeding, or gap analysis.
---

# Industry-Reference Loader

**Layer:** Reference · Intake  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
Brings the reference in as first-class, clearly-segregated ORIEL nodes so crosswalk and gap can compare against it. Reference nodes never masquerade as our facts.

## When to use
Intake step of `benchmark`/`northstar`, or 'load <standard>' requests.

## Inputs
A named reference (+version) and its source (OWL/RDF, ISO 20022 dictionary, BIAN landscape, FIB-DM export).

## Method
1. Parse the reference into concepts, definitions, attributes and relationships, preserving its structure (hierarchy + object properties for FIBO/FIB-DM; business concepts + data types for ISO 20022; service domains + metamodel for BIAN).
2. Record name, publisher (EDM Council / ISO / BIAN) and version (e.g. FIBO 2026/Q1) for reproducibility.
3. Tag every node as a ReferenceConcept under a ReferenceModel; keep it strictly separate from our facts.
4. Note licensing/usage terms so downstream use stays compliant.

## Output → ORIEL
A `ReferenceModel` node + `ReferenceConcept` nodes with definitions and relationships, version-pinned.

## Reference notes
FIBO — EDM Council OWL ontology (Foundations, Business Entities, Finance/Business/Commerce, Securities, Derivatives), updated quarterly. ISO 20022 — 5,200+ business terms + data types; an established seed for a bank's canonical model. BIAN — service domains + a metamodel aligned to ISO 20022. FIB-DM — FIBO transformed into an enterprise ER data model (a structural, not just conceptual, anchor).

## Quality bar
- Reference clearly segregated from our facts.
- Version pinned for reproducibility.
- Relationships preserved, not flattened to a term list.

## Provenance & governance
References carry their own provenance (publisher + version); licensing recorded; they inform, never overwrite.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

