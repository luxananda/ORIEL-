---
name: human-confirm-gate
description: Enforce agent-suggests / human-confirms: present proposed (especially sensitive or low-confidence) facts for ratification and flip status to confirmed or rejected only on explicit human decision. Use for `confirm`/`review`, and mandatory before publishing or treating facts as authoritative.
---

# Human-Confirm Gate

**Layer:** Controls (Layer I)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The control that makes the whole system bank-deployable: no extracted fact is authoritative until a person says so.

## When to use
`confirm <id>` / `review`; before catalog write-back; for all sensitivity tags.

## Inputs
Proposed nodes/edges and the review queue.

## Method
1. Present each item with its statement, provenance, and confidence; group sensitive and high-impact items first.
2. On explicit human decision, set status to confirmed or rejected, record confirmed_by/confirmed_at; otherwise leave proposed.
3. Never auto-confirm — not on high confidence, not on repetition, not on user impatience.

## Output → ORIEL
Status transitions (proposed→confirmed/rejected) with reviewer identity and timestamp.

## Quality bar
- No fact is confirmed without an explicit human decision.
- Sensitivity tags and publish actions always pass through this gate.
- Rejections retained (superseded), not deleted.

## Provenance & governance
The authority boundary of ORIEL; pairs with audit-ledger to record every decision.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

