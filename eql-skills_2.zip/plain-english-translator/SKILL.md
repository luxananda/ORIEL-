---
name: plain-english-translator
description: Translate rules, formulas, code blocks, and workflows into clear business-readable language for a chosen audience. Use when extracting business logic, generating a glossary, or when the user asks to explain something in plain English.
---

# Plain-English Translator

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The narration layer; turns canonical structures into sentences a business reader trusts.

## When to use
Used by code-to-plain-english, the glossary view, and `explain`.

## Inputs
Any ORIEL node (Rule, Formula, Workflow, Field) or a code block.

## Method
1. State the intent first (what/why), then the mechanics, then edge cases — never a line-by-line code echo.
2. Use the entity vocabulary, not implementation identifiers; expand thresholds into meaning (e.g. score above 700).
3. Match the requested audience: business (outcome-focused) or technical (precise).

## Output → ORIEL
`PlainEnglish` nodes linked by DESCRIBES to their target.

## Quality bar
- Intent leads; mechanics follow.
- Uses business vocabulary, not raw identifiers.
- No fabricated behaviour — only what the node supports.

## Provenance & governance
Narratives inherit the confidence of the node they describe and cite it.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

