---
name: feature-equivalence-mapper
description: Map structural and dialect features across platforms — sequences↔identity↔GENERATED, partitioning schemes, index types, ENUM/array/JSON support, and enforced-vs-informational constraints — providing the target equivalent or a documented workaround. Use during migration for everything that is not a plain column type.
---

# Feature-Equivalence Mapper

**Layer:** Migration · Map  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Handles the structural feature gaps that silently break migrations — the things type mapping doesn't cover.

## When to use
Map phase of `migrate`.

## Inputs
Harvested Key/Index/Sequence/Partition sub-nodes and constraint metadata.

## Method
1. For each feature (sequence, identity, partition scheme, index type, constraint enforcement, ENUM, array, materialized view) find the target equivalent.
2. Where none exists, specify a concrete workaround and mark whether it needs a manual decision.
3. Record the gap and rationale so generation and the risk report can use it.

## Output → ORIEL
`FeatureMapping` nodes (feature, target_equivalent | workaround, manual?, note).

## Reference mappings
PG `SERIAL`/`SEQUENCE`→Oracle IDENTITY or SEQUENCE+trigger. Oracle `SEQUENCE`→BigQuery surrogate key / `GENERATE_UUID()` (no native sequences). PK/FK in BigQuery → **informational only, not enforced** → add ELT-side integrity checks. Oracle RANGE/LIST partition → BigQuery date/ingestion-time partition + clustering. Materialized view → BQ materialized view (restricted) or scheduled query.

## Quality bar
- No feature dropped silently.
- Unsupported features carry an explicit workaround or a manual-intervention flag.
- BigQuery's unenforced constraints are called out, not assumed enforced.

## Provenance & governance
Manual-intervention features routed to human-confirm and the risk report.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

