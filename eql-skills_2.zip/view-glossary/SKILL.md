---
name: view-glossary
description: Serve a business glossary and plain-English narratives for entities, rules, formulas, and workflows from the graph. Use when the user wants a glossary, data dictionary in plain language, or to explain a subgraph for a business audience.
---

# Glossary & Plain-English View

**Layer:** Serving (Layer H)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The human-readable face of ORIEL for non-technical stakeholders.

## When to use
`query glossary` / `explain <ref> --audience business`.

## Inputs
Entities, Rules, Formulas, Workflows and their PlainEnglish nodes.

## Method
1. Assemble entity/term definitions with aliases and domains; attach the business-readable statement for each rule/formula/workflow.
2. Where a narrative is missing, request plain-english-translator rather than inventing one.
3. Group by domain; mark any entries still proposed.

## Output → ORIEL
A business glossary view (read-only) drawn from existing graph narratives.

## Quality bar
- No invented definitions — only graph-backed narratives.
- Proposed entries clearly marked.
- Organized by domain for navigation.

## Provenance & governance
Surfaces confidence and status so readers know what is ratified.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

