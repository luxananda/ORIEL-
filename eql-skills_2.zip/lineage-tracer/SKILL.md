---
name: lineage-tracer
description: Trace data lineage source → transform → output across fields and formulas, resolving derived fields back to raw source variables. Use when extracting metadata/formulas or when the user asks where a field comes from or how it is computed.
---

# Lineage Tracer

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Builds the DERIVES_FROM chains that answer `query lineage <field>`.

## When to use
Part of extract-data-metadata and extract-formulas; directly invocable for lineage queries.

## Inputs
Field, Formula, and Key nodes plus transform blocks.

## Method
1. For each output/derived field, follow assignments, joins, and formula variables backwards to raw sources.
2. Iterate until reaching raw source variables (metadata/data-model leaves); record each hop as DERIVES_FROM.
3. Detect and break cycles; flag unresolved hops rather than inventing a source.

## Output → ORIEL
DERIVES_FROM edges forming source→transform→output chains.

## Quality bar
- Chains terminate at raw sources or are explicitly marked unresolved.
- Cycles detected, not infinite-looped.

## Provenance & governance
Each hop EVIDENCED_BY the transform that produced it.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

