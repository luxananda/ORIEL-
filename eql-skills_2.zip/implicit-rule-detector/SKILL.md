---
name: implicit-rule-detector
description: Detect implicit rules — defaults, fallbacks, and unstated assumptions — that are not written as explicit conditionals. Use when extracting domain rules, formulas, or workflows to capture behaviour that lives in defaults and omissions.
---

# Implicit Rule Detector

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Surfaces the rules hiding in default values, catch-all branches, and silent assumptions.

## When to use
Alongside explicit rule extraction.

## Inputs
Normalized blocks, Rule nodes, and Formula/Workflow context.

## Method
1. Identify default parameter values, catch-all/else branches, and 'if X missing → Y' behaviour.
2. Infer assumptions from required-but-undeclared preconditions and from constants used without guards.
3. Phrase each as an ImplicitRule with kind default/fallback/assumption and explicitly mark it inferred.

## Output → ORIEL
`ImplicitRule` nodes (kind, statement), clearly flagged as inferred.

## Quality bar
- Inferred rules never masquerade as explicit ones.
- Each implicit rule cites the default/branch/omission that implies it.

## Provenance & governance
Implicit rules default to lower confidence and route to human-confirm.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

