---
name: audit-ledger
description: Maintain an immutable, append-only record of every extraction run, write, confirmation, rejection, and publish action — what changed, by which skill or person, when, and from which source version. Use to produce an audit trail or reconstruct the state of the catalog at any past time.
---

# Audit Ledger

**Layer:** Controls (Layer I)  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
The regulator-facing memory; makes the catalog defensible and time-travelable.

## When to use
Cross-cutting; every state-changing action appends here.

## Inputs
Run manifests, graph-writer commits, human-confirm decisions, catalog publishes.

## Method
1. Append an immutable entry for each action: actor (skill@version or user), action, target ids, source version, timestamp.
2. Link entries to the bi-temporal versions they created so any past catalog state can be reconstructed.
3. Never edit or delete entries; corrections are new appends.

## Output → ORIEL
An append-only ledger keyed to ORIEL versions and run-ids.

## Quality bar
- Append-only; no edits or deletes.
- Every state change has a ledger entry.
- Past catalog states are reconstructable from the ledger + bi-temporal versions.

## Provenance & governance
The system of record for controls; supports `diff` and point-in-time reporting.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

