---
name: northstar-ontology-modeler
description: Define the target (north-star) business ontology — classes, hierarchy, attributes, and relationships — reference-aligned but bank-specific, capturing where and why it deviates from the standard. Use to set the conceptual target for the semantic layer.
---

# North-Star Ontology Modeler

**Layer:** Reference · North-Star  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The meaning-layer north-star: an opinionated target, not the reference copied.

## When to use
North-star step, conceptual layer.

## Inputs
The reference ontology, our current ontology, and the gap register.

## Composes (does not re-implement)
`ontology-modeler`, `reference-crosswalk-mapper`

## Method
1. Start from the reference ontology where it fits; incorporate our legitimate local concepts; drop reference concepts we do not need (with rationale).
2. Define the target hierarchy, attributes and relationships at the conceptual level.
3. For every deviation from the reference, capture a DesignDecision (why ours differs).
4. Keep the target ALIGNS_TO the reference for traceability.

## Output → ORIEL
A `NorthStarModel` (layer=ontology) with target concepts/relationships + `DesignDecision` nodes.

## Quality bar
- Bank-specific, not a reference clone.
- Every deviation justified.
- Fully traceable to the reference.

## Provenance & governance
Proposed; design decisions are the divergence audit trail; steward/architecture sign-off.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

