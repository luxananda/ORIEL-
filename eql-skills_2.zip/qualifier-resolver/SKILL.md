---
name: qualifier-resolver
description: Resolve region, product, policy, and temporal qualifiers that scope when a rule, formula, or workflow variant applies. Use when extracting formulas/workflows/rules that vary by jurisdiction, product, policy, or time.
---

# Qualifier Resolver

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Captures the context dimensions that turn one rule into many context-specific variants.

## When to use
Used by formula, workflow, and rule extractors.

## Inputs
Rule/Formula/Workflow nodes and surrounding context.

## Method
1. Detect qualifiers from config, feature flags, jurisdiction/product switches, effective dates, and conditional context.
2. Attach qualifiers to the specific variant they scope, not the base node.
3. Normalize temporal qualifiers to explicit valid_from/valid_to where dates are present.

## Output → ORIEL
`Qualifier` nodes and QUALIFIED_BY edges on the relevant variants.

## Quality bar
- Qualifiers scope variants, not bases.
- Temporal qualifiers feed the bi-temporal validity block.

## Provenance & governance
Effective-dated qualifiers set business-time validity, not system-time.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

