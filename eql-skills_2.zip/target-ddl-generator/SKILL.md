---
name: target-ddl-generator
description: Generate target-dialect DDL from ORIEL — CREATE TABLE with columns, defaults, constraints, indexes, sequences/identity, and partitioning — in correct syntax and dependency order, expressing unsupported features via their mapped workarounds. Use to produce the schema-creation scripts for a migration.
---

# Target-DDL Generator

**Layer:** Migration · Generate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
The primary lower step: dialect-neutral ORIEL → runnable target schema.

## When to use
Generate phase of `migrate`.

## Inputs
The canonical schema plus the three mappings (type, feature, identifier).

## Composes (does not re-implement)
`type-system-mapper`, `feature-equivalence-mapper`, `identifier-rules-mapper`

## Method
1. Pull each Entity/Field with its TypeMapping, FeatureMapping, and IdentifierMapping.
2. Emit dialect-correct CREATE statements (tables, constraints, indexes, sequences/identity, partitioning) for the target version.
3. Topologically sort by FK/dependency so the script runs clean on first execution.
4. Inline workarounds for unsupported features as commented blocks that cite the source object.

## Output → ORIEL
`GeneratedArtifact` (target DDL files), REALIZES the source objects, ordered for execution.

## Quality bar
- DDL is syntactically valid for the target dialect + version.
- Statements are dependency-ordered.
- Every statement traces to its source object; workarounds are commented.

## Provenance & governance
Scripts only — never executed. Lossy items reference the risk report; use requires human-confirm.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

