---
name: atomic-proposition-decomposer
description: Decompose complex rules and tables into indivisible atomic propositions (condition→action units) so they can be reasoned over and retrieved precisely. Use when rules/tables are compound and need to be broken into minimal logical units for the graph.
---

# Atomic Proposition Decomposer

**Layer:** ORIEL Graph  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Stage 2 of ORIEL construction; the unit of precise retrieval and multi-hop reasoning.

## When to use
After rule extraction, before indexing.

## Inputs
Rule nodes and table regions.

## Method
1. Split compound rules into minimal condition→action propositions; expand table rows into per-cell propositions where each encodes a rule.
2. Preserve cross-references between propositions (e.g. table call (2,5)) as edges.
3. Keep each proposition independently evidenced.

## Output → ORIEL
`AtomicProposition` nodes and DECOMPOSES_TO edges from their parent.

## Quality bar
- Propositions are truly indivisible.
- Cross-references preserved, not lost in the split.

## Provenance & governance
Each proposition inherits and narrows its parent's provenance.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

