---
name: ddl-harvester
description: Parse full SQL DDL into ORIEL — tables, columns with precision/scale, DEFAULT expressions, NOT NULL, CHECK/UNIQUE/PK/FK constraints, indexes, sequences/identity, partitioning, tablespaces, and comments — capturing everything needed to faithfully recreate the schema on another platform. Use to extract a complete, migration-grade picture of a relational schema.
---

# DDL Harvester

**Layer:** Migration · Harvest  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
The deep, SQL-DDL-specialized harvest. Extends the general schema primitives with every clause a faithful migration needs, retaining original type strings for round-trip fidelity.

## When to use
Harvest phase of `migrate`; or 'extract the full schema/DDL' requests.

## Inputs
DDL text (dialect known) or a live catalog.

## Composes (does not re-implement)
`schema-extractor`, `key-join-detector`, `entity-term-identifier`

## Method
1. Compose schema-extractor (columns, types, nullability) and key-join-detector (PK/FK/UNIQUE/joins) for the base structure.
2. Capture precision/scale, DEFAULT expressions (verbatim + parsed), CHECK constraints, and generated/identity columns; capture sequences with start/increment/cache.
3. Capture indexes (columns, uniqueness, type), partitioning (scheme + key), tablespaces/storage clauses, and object comments.
4. Store dialect-neutrally: a canonical type plus the retained original type string; register name variants as aliases via entity-term-identifier.

## Output → ORIEL
Entities/Fields enriched with full DDL attributes, plus Key / Index / Sequence / Partition sub-nodes; original type strings preserved.

## Quality bar
- Nothing silently dropped — every clause is captured or explicitly flagged unparsed.
- DEFAULT and CHECK kept verbatim and parsed.
- Original type strings retained for round-trip.

## Provenance & governance
Each object EVIDENCED_BY its DDL locator; inferred (catalog-derived) attributes flagged.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

