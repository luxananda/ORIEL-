---
name: schema-extractor
description: Extract schema definitions — fields, datatypes, nullability — from DDL, ORMs, models, API schemas, and tables. Use when extracting data metadata, or when the user asks for the schema/fields/types of a source.
---

# Schema Extractor

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Builds the Field layer and the mandatory-vs-optional signal (NOT NULL → mandatory).

## When to use
Core to extract-data-metadata; reused wherever fields are needed.

## Inputs
Normalized blocks classified as code/DDL/spec/table.

## Method
1. Parse field name, datatype, and nullability from each definition; map vendor types to a canonical type set.
2. Mark NOT NULL / required as mandatory, nullable/optional as optional.
3. Attach each Field to its parent Entity via HAS_FIELD.

## Output → ORIEL
`Field` nodes (datatype, nullable) linked by HAS_FIELD to entities.

## Quality bar
- Mandatory/optional derived from real constraints, not guessed.
- Canonical type mapping is recorded so the source type is recoverable.

## Provenance & governance
Each field carries the locator of its definition.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

