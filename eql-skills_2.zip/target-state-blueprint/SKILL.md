---
name: target-state-blueprint
description: Assemble the north-star into an executive blueprint at the chosen layer — ontology, logical/physical data model, data architecture (domains, mastering, golden sources, flows), or metadata target operating model — with design principles, key decisions, and the rationale for deviating from the reference. Use to produce the single, decision-bearing north-star artifact for leadership.
---

# Target-State Blueprint

**Layer:** Reference · North-Star  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The exec-facing north-star artifact: layer-flexible and decision-capturing. Scope is data/semantic and data architecture — not application/integration architecture.

## When to use
North-star step when a leadership-facing target artifact is needed.

## Inputs
The north-star ontology/data model, the gap register, and design decisions.

## Composes (does not re-implement)
`northstar-ontology-modeler`, `northstar-data-model-builder`, `gap-analyzer`

## Method
1. Select the layer the decision needs: ontology (meaning), data model (structure), data architecture (domains, mastering, golden sources, flows), or metadata target operating model.
2. Assemble the target at that layer with explicit design principles and the key decisions taken.
3. Record every deviation from the industry reference with its rationale — the divergence audit trail.
4. Summarise for leadership: where we are, where we are going, and why.

## Output → ORIEL
A target-state blueprint (`NorthStarModel` + `DesignDecision`) at the chosen layer.

## Quality bar
- Layer matched to the decision.
- Principles and decisions explicit.
- Deviations from the reference justified; readable by leadership.

## Provenance & governance
The divergence rationale is the governance artifact; architecture / data-council sign-off.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

