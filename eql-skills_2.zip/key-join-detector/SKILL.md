---
name: key-join-detector
description: Detect primary keys, foreign keys, unique constraints, and join relationships between entities. Use when extracting data metadata or when the user asks how tables/entities relate.
---

# Key & Join Detector

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Adds the relational topology that lineage and ontology depend on.

## When to use
Part of extract-data-metadata; reused by lineage-tracer and ontology-modeler.

## Inputs
Field nodes and the blocks that define constraints/joins.

## Method
1. Identify PK/UNIQUE from constraints and id conventions; FK from references and join predicates in queries/code.
2. Resolve each FK to the referenced entity.field.
3. Flag inferred (convention-based) keys at lower confidence than declared ones.

## Output → ORIEL
`Key` nodes and KEY_OF edges; FK targets recorded as references.

## Quality bar
- Declared keys outrank inferred keys in confidence.
- Every FK resolves to a real entity.field or is flagged unresolved.

## Provenance & governance
Inferred keys are explicitly lower-confidence and surface in review.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

