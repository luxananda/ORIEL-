---
name: pii-sensitivity-classifier
description: Classify fields as PII, sensitive, or regulated and map each to the regulations it triggers (e.g. MAS 626, PDPA, GDPR, BCBS 239). Use when extracting metadata, building a PII map, or assessing regulatory exposure of a source.
---

# PII & Sensitivity Classifier

**Layer:** Shared Primitive  ·  **Part of:** EQL Engine → ORIEL

## Role in EQL
Produces the compliance layer; for a bank this is the highest-stakes output, so it is conservative and always provenanced.

## When to use
Part of extract-data-metadata; directly invocable for `query pii`.

## Inputs
Field nodes with names, types, sample context, and entities.

## Method
1. Classify each field: public / PII / sensitive-personal / regulated, using name, type, and entity semantics — not value snooping.
2. Map each sensitive field to specific regulation references it implicates; cite the basis for the mapping.
3. Prefer over-flagging to under-flagging; mark uncertain classifications for mandatory human review.

## Output → ORIEL
`SensitivityTag` nodes and TAGGED edges, each with regulation[] and rationale.

## Quality bar
- Errs toward flagging; misses are worse than false positives here.
- Every tag names the regulation and the reason.
- No classification depends on reading actual sensitive values.

## Provenance & governance
All sensitivity tags route to human-confirm before they are authoritative; never auto-confirmed.

## Contract
Reads and writes the ORIEL graph per the shared contract. Every node/edge it
produces carries a full provenance + bi-temporal block and defaults to
`status: proposed`. Only `human-confirm-gate` may set `confirmed`. See the
`eql-orchestrator` skill for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

