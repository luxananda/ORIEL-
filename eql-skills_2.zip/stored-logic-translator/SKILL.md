---
name: stored-logic-translator
description: Translate views, procedures, functions, triggers, and packages to the target dialect — e.g. Oracle PL/SQL → BigQuery scripting/dbt, Postgres PL/pgSQL → Oracle — flagging constructs with no clean equivalent. Use to migrate server-side logic, not just tables.
---

# Stored-Logic Translator

**Layer:** Migration · Generate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
The procedural counterpart to target-ddl-generator.

## When to use
Generate phase of `migrate` when stored logic was harvested.

## Inputs
`StoredLogic` nodes with intent + dependencies, and the target Dialect.

## Composes (does not re-implement)
`stored-logic-harvester`, `plain-english-to-sql`, `feature-equivalence-mapper`

## Method
1. Take each StoredLogic body plus its plain-English intent; re-express it in the target's procedural model.
2. Where the target lacks procedures (or they are limited), push logic to ELT/dbt and say so explicitly.
3. Map dialect constructs (cursors, packages, autonomous transactions, sequence usage) or flag them as manual rewrites.
4. Preserve dependency order so translated objects compile and run.

## Output → ORIEL
`GeneratedArtifact` (translated routines) plus a manual-rewrite list (TRANSLATES the StoredLogic).

## Quality bar
- Dependencies preserved.
- Non-translatable constructs flagged with rationale — never silently approximated.
- Intent preserved, verified against the plain-English summary.

## Provenance & governance
Human-confirm before use; intent-preservation reviewed against the source summary.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

