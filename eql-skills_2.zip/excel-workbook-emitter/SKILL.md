---
name: excel-workbook-emitter
description: Emit governed ORIEL content as structured Excel workbooks for stewards and leadership — the business glossary, the gap-analysis and conformance scorecard, and the north-star model — with validation, dropdowns and reference cross-references. Use to deliver glossary/gap/north-star outputs in Excel, or for steward round-trip review.
---

# Excel Workbook Emitter

**Layer:** Reference · Delivery  ·  **Pack:** EQL Reference & North-Star → ORIEL

## Role in EQL
The outbound half of the Excel round-trip and the tangible deliverable layer. Composes the environment's xlsx tooling to build the actual files.

## When to use
Delivery step, or any 'give me this as an Excel workbook' request.

## Inputs
A workbook type (glossary / gap-analysis / north-star) and the ORIEL content to render.

## Composes (does not re-implement)
`glossary-builder`, `gap-analyzer`, `target-state-blueprint`, `xlsx`

## Method
1. Select the workbook type — glossary (term/definition/owner/domain/status/aliases/reference-mapping), gap-analysis (current vs reference, missing/divergent/extra, coverage %, recommendation, priority), or north-star (entities/attributes/keys/relationships, reference alignment, design decisions).
2. Render the chosen ORIEL view into a structured workbook with headers, data validation (status/owner dropdowns) and a reference cross-reference column.
3. Include a provenance/owner column and a status column so the workbook stays reviewable and re-importable via glossary-excel-importer.
4. Build the file through the xlsx tooling; default to confirmed content, with a flag to include proposed (clearly marked).

## Output → ORIEL
An .xlsx workbook (glossary / gap-analysis / north-star) plus a link back to the ORIEL nodes it renders.

## Quality bar
- Every workbook is round-trippable (stable keys, provenance, status).
- Validation/dropdowns present.
- Proposed vs confirmed clearly marked.

## Provenance & governance
Default export is confirmed-only; proposed content flagged; the workbook is an interface, ORIEL stays the system of record.

## Contract
Reads and writes ORIEL per the shared contract, including the Reference &
North-Star extension (ReferenceModel, ReferenceConcept, Crosswalk, GapItem,
ConformanceScore, NorthStarModel, DesignDecision, RoadmapItem). A reference is a
**benchmark, not an authority**: our concepts are never overwritten by a standard;
deviations carry a DesignDecision. Every node carries provenance + bi-temporal
blocks, defaults to `status: proposed`, and only `human-confirm-gate` confirms it.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

