---
name: migration-equivalence-checker
description: Verify the target schema and data are semantically equivalent to the source — column/type/constraint parity, object counts, and a rowcount/checksum reconciliation plan — and produce a precise diff of what changed and why. Use to validate a migration before sign-off.
---

# Migration Equivalence Checker

**Layer:** Migration · Validate  ·  **Pack:** EQL Migration → ORIEL

## Role in EQL
Trust: proves the migration preserved meaning rather than just producing runnable SQL.

## When to use
Validate phase of `migrate`, after generation (and after target build, if available).

## Inputs
Source ORIEL + the generated target (re-harvested where a built target exists).

## Composes (does not re-implement)
`ddl-harvester`

## Method
1. Re-harvest the target with ddl-harvester and diff it against the source graph.
2. Check parity of columns, types, constraints, and indexes object-by-object.
3. Define rowcount + checksum/aggregate reconciliation per table.
4. Classify every difference as intended (mapped/lossy/workaround) or defect.

## Output → ORIEL
An equivalence report: parity matrix + reconciliation plan + classified difference list.

## Quality bar
- Every difference classified intended vs defect.
- Reconciliation covers all migrated tables.
- Lossy differences cross-referenced to their mapping.

## Provenance & governance
Defects block sign-off; intended differences must trace to an acknowledged mapping.

## Contract
Reads and writes the ORIEL graph per the shared contract, including the
Migration extension (Dialect, TypeMapping, FeatureMapping, IdentifierMapping,
StoredLogic, GeneratedArtifact, MigrationPlan, MigrationRisk). Every node/edge
carries provenance + bi-temporal blocks and defaults to `status: proposed`.
Generated SQL is **never executed**; only `human-confirm-gate` authorises use.
See `eql-orchestrator` for `ORIEL_SCHEMA.md` and `EQL_SPEC.md`.

