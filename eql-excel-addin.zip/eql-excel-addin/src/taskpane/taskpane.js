/* EQL · Glossary Builder — task pane logic */
const COLS = ["Term", "Definition", "Domain", "Owner", "Status", "Reference (FIBO/ISO 20022)", "Source"];

let statusEl, runBtn;

Office.onReady((info) => {
  if (info.host !== Office.HostType.Excel) return;
  statusEl = document.getElementById("status");
  runBtn = document.getElementById("run");
  runBtn.disabled = false;
  runBtn.addEventListener("click", buildGlossary);
  setStatus("Select cells with terms, then click the button.");
});

function setStatus(msg, kind = "") {
  statusEl.textContent = msg;
  statusEl.className = "status" + (kind ? " " + kind : "");
}

async function buildGlossary() {
  runBtn.disabled = true;
  try {
    const terms = await readSelectedTerms();
    if (terms.length === 0) {
      setStatus("No non-empty cells selected. Select a column of terms first.", "err");
      return;
    }
    setStatus(`Sending ${terms.length} term(s) to the EQL engine…`);

    const res = await fetch("/api/glossary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ terms })
    });
    if (!res.ok) throw new Error(`Backend ${res.status}: ${await res.text()}`);
    const data = await res.json();
    const rows = Array.isArray(data.rows) ? data.rows : [];
    if (rows.length === 0) throw new Error("The engine returned no rows.");

    await writeGlossarySheet(rows);
    setStatus(`Done — ${rows.length} proposed term(s) written to “EQL Glossary”.`, "ok");
  } catch (err) {
    console.error(err);
    setStatus("Error: " + (err.message || err), "err");
  } finally {
    runBtn.disabled = false;
  }
}

async function readSelectedTerms() {
  return Excel.run(async (ctx) => {
    const range = ctx.workbook.getSelectedRange();
    range.load("values");
    await ctx.sync();
    const flat = [];
    for (const row of range.values) {
      for (const cell of row) {
        const v = (cell === null || cell === undefined) ? "" : String(cell).trim();
        if (v) flat.push(v);
      }
    }
    // de-duplicate, preserve order
    return [...new Set(flat)];
  });
}

async function writeGlossarySheet(rows) {
  return Excel.run(async (ctx) => {
    const sheets = ctx.workbook.worksheets;
    const name = "EQL Glossary";
    // delete existing sheet of this name, if present
    const existing = sheets.getItemOrNullObject(name);
    existing.load("name");
    await ctx.sync();
    if (!existing.isNullObject) existing.delete();

    const sheet = sheets.add(name);
    sheet.activate();

    const matrix = rows.map((r) => COLS.map((c) => valueFor(r, c)));
    const all = [COLS, ...matrix];

    const body = sheet.getRangeByIndexes(0, 0, all.length, COLS.length);
    body.values = all;

    const header = sheet.getRangeByIndexes(0, 0, 1, COLS.length);
    header.format.fill.color = "#B0664B";
    header.format.font.color = "#FBF8F1";
    header.format.font.bold = true;

    sheet.getUsedRange().format.autofitColumns();
    sheet.freezePanes.freezeRows(1);
    await ctx.sync();
  });
}

function valueFor(r, col) {
  const map = {
    "Term": r.term, "Definition": r.definition, "Domain": r.domain,
    "Owner": r.owner, "Status": r.status || "proposed",
    "Reference (FIBO/ISO 20022)": r.reference, "Source": r.source
  };
  const v = map[col];
  return v === null || v === undefined ? "" : String(v);
}
