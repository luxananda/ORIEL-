# EQL · Glossary Builder — Excel Add-in

Your own Excel task-pane add-in (like the "Claude" button, but yours). Select cells
with terms → click **Glossary Builder** → a governed glossary is written to a new
"EQL Glossary" sheet (term · definition · domain · owner · status · industry-reference
cross-reference · source). Every row is **proposed** — a steward confirms it.

```
manifest.xml            add-in-only manifest (Excel host, ribbon button)
package.json            backend deps + sideload scripts
server/server.js        serves the panel over HTTPS + POST /api/glossary → Claude
server/.env.example     where your API key goes (server only)
src/taskpane/           the panel: HTML / CSS / Office.js logic
assets/                 icon-32.png, icon-80.png (add your own; optional)
```

## Run it (dev)

Prereqs: **Node.js LTS**, **Excel** signed into Microsoft 365, an **Anthropic API key**.

```bash
npm install
npm run certs                 # one-time: trust the localhost HTTPS cert (Office requires HTTPS)
cp server/.env.example server/.env
#   …open server/.env and paste your ANTHROPIC_API_KEY

# terminal 1 — start the backend + panel (https://localhost:3000)
npm run serve

# terminal 2 — sideload into Excel (opens Excel with the EQL button on Home)
npm start
```

In Excel: **Home → Glossary Builder** opens the panel. Select a column of terms, click
**Build glossary from selection**. (If you don't see the button, click **Add-ins** and
pick the sideloaded add-in.)

> Add a real GUID to `manifest.xml` (`<Id>`) before deploying — run `uuidgen`.
> Drop `icon-32.png` / `icon-80.png` into `assets/` so the ribbon icon renders.

## Upgrade to your real EQL skills

The starter inlines the glossary method so it runs immediately. To use your **uploaded
EQL skills** instead:

1. Upload each skill folder via the Skills API → get a `skill_id` per skill.
2. Put the IDs in `server/.env` (`SKILL_GLOSSARY_BUILDER`, …).
3. In `server/server.js`, uncomment the `betas` / `container.skills` / `tools` block and
   the `anthropic-beta` header (max **8 skills per request** — load `eql-orchestrator`
   plus the few relevant ones and let it route).

Add more buttons the same way (gap-analysis, north-star) — each is another `/api/*`
route + a panel action that writes its sheet.

## Deploy (production)

- **Split the two layers:** host `src/taskpane/` as a static site on HTTPS; run the
  backend separately (Azure Functions / a small Node service) holding the key.
- Update `manifest.xml` URLs from `localhost:3000` to your hosted HTTPS domain.
- Distribute via **Centralized Deployment** in the Microsoft 365 admin center
  (Integrated Apps): IT uploads the manifest and pushes it to a pilot group — no local
  install. (AppSource only if you ever want it public.)

## Bank governance & security

- The API key is **only** on the backend; the panel never sees it. Route the backend
  through your approved enterprise-AI gateway.
- Rows are written as `proposed`; ORIEL / your glossary system of record stays
  authoritative. Nothing is auto-published — agent suggests, human confirms.
- Roll out to a pilot group via Integrated Apps before any wider deployment; data
  leaving to the API goes through your security review like any other add-in.
