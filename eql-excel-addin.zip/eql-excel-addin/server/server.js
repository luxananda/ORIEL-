/* EQL Glossary Builder — backend.
   Serves the task pane over HTTPS (localhost:3000) AND exposes POST /api/glossary.
   The Anthropic API key lives ONLY here, never in the task pane. */
require("dotenv").config();
const path = require("path");
const https = require("https");
const http = require("http");
const express = require("express");
const cors = require("cors");

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.EQL_MODEL || "claude-sonnet-4-6";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "src", "taskpane")));
app.use("/assets", express.static(path.join(__dirname, "..", "assets")));

// ---- the EQL glossary method, inlined so the starter runs without uploaded skills ----
const SYSTEM = `You are the EQL glossary engine for a tier-1 bank. Given a list of business
terms, produce one governed glossary row per DISTINCT business concept.

Rules:
- One canonical term per concept; fold obvious variants together.
- "definition": a precise, business-readable definition (<= 40 words). Do not invent
  bank-specific meaning you cannot justify; keep it general where unsure.
- "domain": the business domain (e.g. Customer, Payments, Risk, Reference Data).
- "owner": "" unless an owner is clearly implied — NEVER invent an owner.
- "status": always "proposed".
- "reference": if the concept maps to a financial-industry standard, cite it briefly
  (e.g. "FIBO: LegalEntity", "ISO 20022: PartyIdentification"); else "".
- "source": "selection" (these came from the user's selected cells).

Return STRICT JSON only, no prose, no code fences:
{"rows":[{"term":"","definition":"","domain":"","owner":"","status":"proposed","reference":"","source":"selection"}]}`;

app.post("/api/glossary", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).send("ANTHROPIC_API_KEY not set on the server.");
    const terms = Array.isArray(req.body.terms) ? req.body.terms.slice(0, 200) : [];
    if (terms.length === 0) return res.status(400).send("No terms provided.");

    const body = {
      model: MODEL,
      max_tokens: 4000,
      system: SYSTEM,
      messages: [{ role: "user", content: "Terms:\n" + terms.map((t) => "- " + t).join("\n") }]

      // ── UPGRADE TO YOUR REAL EQL SKILLS ───────────────────────────────
      // After uploading your skills via the Skills API, swap the inline
      // SYSTEM prompt above for your uploaded skills and code execution:
      //
      // betas: ["code-execution-2025-08-25", "skills-2025-10-02"],
      // container: { skills: [
      //   { type: "custom", skill_id: process.env.SKILL_GLOSSARY_BUILDER, version: "latest" },
      //   { type: "custom", skill_id: process.env.SKILL_DEFINITION_HARMONIZER, version: "latest" }
      // ]},
      // tools: [{ type: "code_execution_20250825", name: "code_execution" }],
      // (and send the beta header below)
      // ──────────────────────────────────────────────────────────────────
    };

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01"
        // , "anthropic-beta": "code-execution-2025-08-25,skills-2025-10-02"   // for skills mode
      },
      body: JSON.stringify(body)
    });

    if (!r.ok) return res.status(502).send("Claude API " + r.status + ": " + (await r.text()));
    const data = await r.json();
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    res.json(parseRows(text));
  } catch (err) {
    console.error(err);
    res.status(500).send(String(err.message || err));
  }
});

function parseRows(text) {
  let s = (text || "").trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  try {
    const obj = JSON.parse(s);
    return { rows: Array.isArray(obj.rows) ? obj.rows : [] };
  } catch {
    return { rows: [] };
  }
}

// ---- serve over HTTPS in dev (Office requires HTTPS); fall back to HTTP ----
(async () => {
  try {
    const devCerts = require("office-addin-dev-certs");
    const opts = await devCerts.getHttpsServerOptions();
    https.createServer({ key: opts.key, cert: opts.cert, ca: opts.ca }, app)
      .listen(PORT, () => console.log(`EQL add-in (HTTPS) on https://localhost:${PORT}`));
  } catch (e) {
    console.warn("HTTPS certs unavailable (" + e.message + ") — starting HTTP. Run `npm run certs` first for Office.");
    http.createServer(app).listen(PORT, () => console.log(`EQL add-in (HTTP) on http://localhost:${PORT}`));
  }
})();
